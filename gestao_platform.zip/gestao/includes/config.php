<?php
// includes/config.php — gerado pelo instalador
define('DB_HOST',    'localhost');
define('DB_NAME',    'gestao');
define('DB_USER',    'gestao');
define('DB_PASS',    'changeme');
define('DB_CHARSET', 'utf8mb4');
define('APP_NAME',   'Gestão Administrativa');
define('APP_VERSION','1.0.0');
define('APP_URL',    'http://localhost');
define('APP_BASE',   '/gestao');
define('EXPORT_DIR', __DIR__ . '/../exports/');
define('UPLOAD_DIR', __DIR__ . '/../uploads/');
define('SESSION_LIFETIME', 86400 * 30);

function url(string $path = '/'): string {
    $base = rtrim(APP_BASE, '/');
    if ($path === '/') return $base . '/';
    return $base . '/' . ltrim($path, '/');
}

function asset(string $path): string {
    return url('/assets/' . ltrim($path, '/'));
}
