<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/core.php';
require_once __DIR__ . '/../../includes/layout.php';
Auth::start(); Auth::require();
page_start('Meu Perfil','perfil');
pageHeader('👤 Meu Perfil');
flashMessage();
?>
<div class="card">
  <div class="card-body">
    <div class="callout callout-info">
      <span>🚧</span>
      <div>Módulo <strong>Meu Perfil</strong> em desenvolvimento. As funcionalidades estarão disponíveis em breve.</div>
    </div>
  </div>
</div>
<?php page_end(); ?>
