<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/core.php';
require_once __DIR__ . '/../../includes/layout.php';

Auth::start(); Auth::require();

$action = $_GET['action'] ?? '';
$id     = (int)($_GET['id'] ?? 0);
$msg    = '';

// ── POST: criar/editar/atualizar status ───────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $p = $_POST;

    if ($p['_action'] === 'criar') {
        $numero = gerarNumero('CHM', 'chamados');
        $slaH   = match($p['prioridade'] ?? 'media') { 'critica'=>4,'alta'=>8,'media'=>24,'baixa'=>72, default=>24 };
        $prazo  = date('Y-m-d H:i:s', strtotime("+{$slaH} hours"));
        $newId  = DB::insert(
            "INSERT INTO chamados (numero,titulo,descricao,categoria,prioridade,filial_id,aberto_por,sla_horas,prazo_sla)
             VALUES (?,?,?,?,?,?,?,?,?)",
            [$numero, $p['titulo'], $p['descricao'], $p['categoria'], $p['prioridade'],
             $p['filial_id'] ?: null, Auth::id(), $slaH, $prazo]
        );
        DB::run("INSERT INTO chamados_historico (chamado_id,user_id,acao,mensagem) VALUES (?,?,?,?)",
            [$newId, Auth::id(), 'Chamado aberto', $p['titulo']]);
        Log::write('chamados', 'criar', "Chamado $numero criado");
        setFlash("Chamado $numero aberto com sucesso!", 'success');
        header('Location: ' . url('/pages/chamados.php')); exit;
    }

    if ($p['_action'] === 'atualizar' && $id) {
        DB::run(
            "UPDATE chamados SET status=?,atendente_id=?,descricao=? WHERE id=?",
            [$p['status'], $p['atendente_id'] ?: null, $p['descricao'], $id]
        );
        if (in_array($p['status'], ['resolvido','fechado']) ) {
            DB::run("UPDATE chamados SET data_resolucao=NOW() WHERE id=? AND data_resolucao IS NULL", [$id]);
        }
        DB::run("INSERT INTO chamados_historico (chamado_id,user_id,acao,mensagem) VALUES (?,?,?,?)",
            [$id, Auth::id(), 'Status atualizado para ' . $p['status'], $p['obs'] ?? '']);
        setFlash('Chamado atualizado!', 'success');
        header('Location: ' . url("/pages/chamados.php?id=$id")); exit;
    }
}

// ── View single chamado ───────────────────────────────────────
if ($id && !$action) {
    $chamado = DB::one(
        "SELECT c.*, f.nome as filial_nome, u.nome as aberto_nome, a.nome as atendente_nome
         FROM chamados c
         LEFT JOIN filiais f ON c.filial_id=f.id
         LEFT JOIN users u ON c.aberto_por=u.id
         LEFT JOIN users a ON c.atendente_id=a.id
         WHERE c.id=?", [$id]
    );
    $historico = DB::all(
        "SELECT h.*, u.nome FROM chamados_historico h LEFT JOIN users u ON h.user_id=u.id WHERE h.chamado_id=? ORDER BY h.created_at ASC",
        [$id]
    );

    page_start('Chamado ' . ($chamado['numero'] ?? ''), 'chamados');
    pageHeader('🎫 ' . ($chamado['numero'] ?? ''), $chamado['titulo'] ?? '', [
        ['label'=>'← Voltar', 'href'=>url('/pages/chamados.php'), 'cls'=>'btn-outline'],
    ]);
    flashMessage();
    if ($chamado): ?>

    <div class="dashboard-grid">
      <div>
        <div class="card mb-2">
          <div class="card-header">
            <span class="card-title">Detalhes</span>
            <?= statusBadge($chamado['status']) ?> <?= statusBadge($chamado['prioridade']) ?>
          </div>
          <div class="card-body">
            <div class="form-grid form-grid-2" style="margin-bottom:12px">
              <div><div class="text-xs text-muted">Número</div><div class="text-mono fw-bold"><?= htmlspecialchars($chamado['numero']) ?></div></div>
              <div><div class="text-xs text-muted">Filial</div><div><?= htmlspecialchars($chamado['filial_nome'] ?? '—') ?></div></div>
              <div><div class="text-xs text-muted">Aberto por</div><div><?= htmlspecialchars($chamado['aberto_nome'] ?? '—') ?></div></div>
              <div><div class="text-xs text-muted">Atendente</div><div><?= htmlspecialchars($chamado['atendente_nome'] ?? 'Não atribuído') ?></div></div>
              <div><div class="text-xs text-muted">Categoria</div><div><?= ucfirst(str_replace('_',' ', $chamado['categoria'])) ?></div></div>
              <div><div class="text-xs text-muted">SLA</div>
                <div class="text-mono <?= slaClass($chamado['prazo_sla']) ?>">
                  <?= $chamado['prazo_sla'] ? formatDate($chamado['prazo_sla'], true) : '—' ?>
                </div>
              </div>
            </div>
            <div class="text-xs text-muted mb-1">Descrição</div>
            <p style="font-size:.9rem;line-height:1.6;color:var(--t2)"><?= nl2br(htmlspecialchars($chamado['descricao'])) ?></p>
          </div>
        </div>

        <!-- Update form -->
        <?php if (Auth::isGestor() || $chamado['atendente_id'] == Auth::id()): ?>
        <div class="card">
          <div class="card-header"><span class="card-title">Atualizar Chamado</span></div>
          <div class="card-body">
            <form method="POST">
              <input type="hidden" name="_action" value="atualizar">
              <div class="form-grid form-grid-2" style="margin-bottom:12px">
                <div class="form-group">
                  <label class="form-label">Status</label>
                  <select name="status" class="form-select">
                    <?= selectOptions([
                      ['v'=>'aberto','l'=>'Aberto'],
                      ['v'=>'em_atendimento','l'=>'Em Atendimento'],
                      ['v'=>'aguardando','l'=>'Aguardando'],
                      ['v'=>'resolvido','l'=>'Resolvido'],
                      ['v'=>'fechado','l'=>'Fechado'],
                    ], 'v', 'l', $chamado['status']) ?>
                  </select>
                </div>
                <div class="form-group">
                  <label class="form-label">Atendente</label>
                  <select name="atendente_id" class="form-select">
                    <?= selectOptions(users(), 'id', 'nome', $chamado['atendente_id'], 'Selecione...') ?>
                  </select>
                </div>
              </div>
              <div class="form-group" style="margin-bottom:12px">
                <label class="form-label">Descrição / Atualização</label>
                <textarea name="descricao" class="form-textarea"><?= htmlspecialchars($chamado['descricao']) ?></textarea>
              </div>
              <div class="form-group">
                <label class="form-label">Observação (log)</label>
                <input type="text" name="obs" class="form-input" placeholder="Descreva o que foi feito...">
              </div>
              <div class="btn-row mt-1"><button class="btn btn-primary">💾 Salvar Atualização</button></div>
            </form>
          </div>
        </div>
        <?php endif; ?>
      </div>

      <!-- Histórico -->
      <div class="card" style="height:fit-content">
        <div class="card-header"><span class="card-title">📜 Histórico</span></div>
        <div class="card-body">
          <div class="timeline">
            <?php foreach ($historico as $h): ?>
            <div class="timeline-item">
              <div class="timeline-dot"></div>
              <div class="timeline-time"><?= formatDate($h['created_at'], true) ?> — <?= htmlspecialchars($h['nome'] ?? 'Sistema') ?></div>
              <div class="timeline-content"><strong><?= htmlspecialchars($h['acao']) ?></strong><?= $h['mensagem'] ? '<br>' . htmlspecialchars($h['mensagem']) : '' ?></div>
            </div>
            <?php endforeach; ?>
          </div>
        </div>
      </div>
    </div>

    <?php endif;
    page_end(); exit;
}

// ── Listagem ──────────────────────────────────────────────────
$filter_status   = $_GET['status'] ?? '';
$filter_prioridade = $_GET['prioridade'] ?? '';
$filter_filial   = (int)($_GET['filial'] ?? 0);
$search          = trim($_GET['q'] ?? '');

$where = ['1=1']; $params = [];
if ($filter_status)    { $where[] = 'c.status=?';     $params[] = $filter_status; }
if ($filter_prioridade){ $where[] = 'c.prioridade=?'; $params[] = $filter_prioridade; }
if ($filter_filial)    { $where[] = 'c.filial_id=?';  $params[] = $filter_filial; }
if ($search)           { $where[] = '(c.titulo LIKE ? OR c.numero LIKE ?)'; $params[] = "%$search%"; $params[] = "%$search%"; }

$chamados = DB::all(
    "SELECT c.*, f.nome as filial_nome, u.nome as atendente_nome,
     TIMESTAMPDIFF(HOUR, NOW(), c.prazo_sla) as sla_horas_rest
     FROM chamados c
     LEFT JOIN filiais f ON c.filial_id=f.id
     LEFT JOIN users u ON c.atendente_id=u.id
     WHERE " . implode(' AND ', $where) . "
     ORDER BY FIELD(c.prioridade,'critica','alta','media','baixa'), c.created_at DESC",
    $params
);

// SLA stats
$slaVencidos = DB::count('chamados', "status IN ('aberto','em_atendimento') AND prazo_sla < NOW()");
$slaCriticos = DB::count('chamados', "status IN ('aberto','em_atendimento') AND prazo_sla BETWEEN NOW() AND DATE_ADD(NOW(), INTERVAL 4 HOUR)");

page_start('Chamados', 'chamados');
pageHeader('🎫 Chamados', 'Gestão de chamados e atendimentos', [
    ['label' => '+ Novo Chamado', 'href' => '#', 'onclick' => "openModal('modalChamado')", 'cls' => 'btn-primary'],
]);
flashMessage();
?>

<!-- SLA Quick Stats -->
<div class="stats-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:20px">
  <?php statCard('Total Abertos',     DB::count('chamados', "status IN ('aberto','em_atendimento')"), '📬', 'blue'); ?>
  <?php statCard('SLA Vencidos',      $slaVencidos, '🚨', $slaVencidos > 0 ? 'red' : 'green'); ?>
  <?php statCard('SLA Críticos',      $slaCriticos, '⚠️', $slaCriticos > 0 ? 'yellow' : 'green'); ?>
  <?php statCard('Resolvidos Hoje',   DB::count('chamados', "DATE(data_resolucao)=CURDATE()"), '✅', 'green'); ?>
</div>

<!-- Filters -->
<div class="filters-bar">
  <div class="filter-group">
    <span class="filter-label">Buscar</span>
    <input type="text" class="filter-input filter-search" placeholder="Nº ou título..." id="searchInput" value="<?= htmlspecialchars($search) ?>">
  </div>
  <div class="filter-group">
    <span class="filter-label">Status</span>
    <select class="filter-select" id="filterStatus" onchange="applyFilters()">
      <option value="">Todos</option>
      <option value="aberto" <?= $filter_status==='aberto'?'selected':'' ?>>Aberto</option>
      <option value="em_atendimento" <?= $filter_status==='em_atendimento'?'selected':'' ?>>Em Atendimento</option>
      <option value="resolvido" <?= $filter_status==='resolvido'?'selected':'' ?>>Resolvido</option>
      <option value="fechado" <?= $filter_status==='fechado'?'selected':'' ?>>Fechado</option>
    </select>
  </div>
  <div class="filter-group">
    <span class="filter-label">Prioridade</span>
    <select class="filter-select" onchange="applyFilters()" id="filterPrio">
      <option value="">Todas</option>
      <option value="critica" <?= $filter_prioridade==='critica'?'selected':'' ?>>Crítica</option>
      <option value="alta" <?= $filter_prioridade==='alta'?'selected':'' ?>>Alta</option>
      <option value="media" <?= $filter_prioridade==='media'?'selected':'' ?>>Média</option>
      <option value="baixa" <?= $filter_prioridade==='baixa'?'selected':'' ?>>Baixa</option>
    </select>
  </div>
  <div class="filter-group">
    <span class="filter-label">Filial</span>
    <select class="filter-select" onchange="applyFilters()" id="filterFilial">
      <option value="">Todas</option>
      <?= selectOptions(filiais(), 'id', 'nome', $filter_filial) ?>
    </select>
  </div>
  <button class="btn btn-outline" onclick="clearFilters()">✕ Limpar</button>
</div>

<!-- Table -->
<div class="card">
  <div class="table-wrapper">
    <table class="data-table" id="chamadosTable">
      <thead><tr>
        <th>Número</th><th>Título</th><th>Categoria</th>
        <th>Prioridade</th><th>Status</th><th>SLA</th>
        <th>Filial</th><th>Atendente</th><th>Abertura</th><th>Ações</th>
      </tr></thead>
      <tbody>
        <?php if (empty($chamados)): ?>
        <tr><td colspan="10" style="text-align:center;padding:32px;color:var(--t3)">Nenhum chamado encontrado</td></tr>
        <?php else: foreach ($chamados as $c):
          $slaRest = (int)$c['sla_horas_rest'];
          $slaCls  = in_array($c['status'],['resolvido','fechado']) ? '' : ($slaRest < 0 ? 'sla-danger' : ($slaRest < 4 ? 'sla-danger' : ($slaRest < 24 ? 'sla-warn' : 'sla-ok')));
        ?>
        <tr>
          <td class="td-mono"><a href="<?= url('/pages/chamados.php?id=' . $c['id']) ?>"><?= htmlspecialchars($c['numero']) ?></a></td>
          <td><strong><?= htmlspecialchars($c['titulo']) ?></strong></td>
          <td><?= ucfirst(str_replace('_',' ',$c['categoria'])) ?></td>
          <td><?= prioridadeIcon($c['prioridade']) ?> <?= statusBadge($c['prioridade']) ?></td>
          <td><?= statusBadge($c['status']) ?></td>
          <td class="td-mono <?= $slaCls ?>">
            <?php if (in_array($c['status'],['resolvido','fechado'])): ?>
              <span class="badge badge-green">✓</span>
            <?php else: ?>
              <?= $c['prazo_sla'] ? formatDate($c['prazo_sla'], true) : '—' ?>
              <?php if ($slaRest < 0): ?><span class="badge badge-red">Vencido</span><?php endif; ?>
            <?php endif; ?>
          </td>
          <td><?= htmlspecialchars($c['filial_nome'] ?? '—') ?></td>
          <td><?= htmlspecialchars($c['atendente_nome'] ?? '—') ?></td>
          <td class="td-mono text-xs"><?= formatDate($c['created_at']) ?></td>
          <td class="td-actions">
            <a href="<?= url('/pages/chamados.php?id=' . $c['id']) ?>" class="btn btn-xs btn-outline">Ver</a>
          </td>
        </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Modal: Novo Chamado -->
<div class="modal-overlay" id="modalChamado">
  <div class="modal">
    <div class="modal-header">
      <span class="modal-title">🎫 Abrir Novo Chamado</span>
      <button class="modal-close" onclick="closeModal('modalChamado')">✕</button>
    </div>
    <form method="POST">
      <input type="hidden" name="_action" value="criar">
      <div class="modal-body">
        <div class="form-grid" style="gap:14px">
          <div class="form-group">
            <label class="form-label">Título <span class="form-required">*</span></label>
            <input type="text" name="titulo" class="form-input" placeholder="Descreva o problema..." required>
          </div>
          <div class="form-grid form-grid-3">
            <div class="form-group">
              <label class="form-label">Categoria</label>
              <select name="categoria" class="form-select">
                <option value="ti">TI</option>
                <option value="predial">Predial</option>
                <option value="administrativo">Administrativo</option>
                <option value="financeiro">Financeiro</option>
                <option value="rh">RH</option>
                <option value="outros">Outros</option>
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">Prioridade</label>
              <select name="prioridade" class="form-select">
                <option value="baixa">🟢 Baixa</option>
                <option value="media" selected>🟡 Média</option>
                <option value="alta">🟠 Alta</option>
                <option value="critica">🔴 Crítica</option>
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">Filial</label>
              <select name="filial_id" class="form-select">
                <?= selectOptions(filiais(), 'id', 'nome') ?>
              </select>
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">Descrição detalhada</label>
            <textarea name="descricao" class="form-textarea" rows="4" placeholder="Descreva o problema com detalhes..."></textarea>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline" onclick="closeModal('modalChamado')">Cancelar</button>
        <button type="submit" class="btn btn-primary">🎫 Abrir Chamado</button>
      </div>
    </form>
  </div>
</div>

<script>
function applyFilters() {
  const s = document.getElementById('filterStatus').value;
  const p = document.getElementById('filterPrio').value;
  const f = document.getElementById('filterFilial').value;
  const q = document.getElementById('searchInput').value;
  const params = new URLSearchParams({status:s, prioridade:p, filial:f, q});
  window.location.href = '<?= url('/pages/chamados.php') ?>?' + params.toString();
}
function clearFilters() {
  window.location.href = '<?= url('/pages/chamados.php') ?>';
}
function slaClass(h) {
  if (h < 0) return 'sla-danger';
  if (h < 4) return 'sla-danger';
  if (h < 24) return 'sla-warn';
  return 'sla-ok';
}
</script>

<?php page_end(); ?>
