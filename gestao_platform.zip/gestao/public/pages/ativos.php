<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/core.php';
require_once __DIR__ . '/../../includes/layout.php';
Auth::start(); Auth::require();
page_start('Ativos & Equipamentos','ativos');
pageHeader('🖥 Ativos & Equipamentos');
flashMessage();
?>
<div class="card">
  <div class="card-body">
    <div class="callout callout-info">
      <span>🚧</span>
      <div>Módulo <strong>Ativos & Equipamentos</strong> em desenvolvimento. As funcionalidades estarão disponíveis em breve.</div>
    </div>
  </div>
</div>
<?php page_end(); ?>
