<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/core.php';
header('Content-Type: application/json');
Auth::start();
$uid = Auth::id();
if (!$uid) { http_response_code(401); echo json_encode(['error'=>'unauthenticated']); exit; }

$body   = json_decode(file_get_contents('php://input'), true) ?? [];
$action = $body['action'] ?? '';

switch ($action) {
    case 'notif_mark_all':
        Notif::markAllRead();
        echo json_encode(['ok' => true]);
        break;
    case 'notif_mark':
        Notif::markRead((int)($body['id'] ?? 0));
        echo json_encode(['ok' => true]);
        break;
    case 'notif_count':
        echo json_encode(['count' => Notif::unreadCount()]);
        break;
    default:
        http_response_code(400);
        echo json_encode(['error' => 'unknown_action']);
}
