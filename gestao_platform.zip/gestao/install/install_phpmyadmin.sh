#!/bin/bash
# ============================================================
#  phpMyAdmin — Instalador Automático
#  Ubuntu 20.04 / 22.04 / 24.04 — Apache2
#  Acesso: http://IP/phpmyadmin
# ============================================================
set -e
RED='\033[0;31m'; GRN='\033[0;32m'; YLW='\033[1;33m'; CYN='\033[0;36m'; BLD='\033[1m'; RST='\033[0m'
log()  { echo -e "  ${GRN}✓${RST} $1"; }
warn() { echo -e "  ${YLW}!${RST} $1"; }
err()  { echo -e "  ${RED}✗${RST} $1"; exit 1; }
step() { echo -e "\n  ${CYN}▶${RST} ${BLD}$1${RST}"; }

[ "$EUID" -ne 0 ] && err "Execute como root: sudo bash install_phpmyadmin.sh"

echo -e "\n  ${CYN}${BLD}╔══════════════════════════════════════════════╗${RST}"
echo -e "  ${CYN}${BLD}║   phpMyAdmin — Instalador                    ║${RST}"
echo -e "  ${CYN}${BLD}╚══════════════════════════════════════════════╝${RST}\n"

# ── Configurações ─────────────────────────────────────────────
read -p "  Subpasta de acesso [phpmyadmin]: " INPUT_DIR
PMA_DIR="${INPUT_DIR:-phpmyadmin}"
PMA_DIR="${PMA_DIR#/}"

read -p "  DocumentRoot do Apache [/var/www/html]: " INPUT_DOCROOT
DOCROOT="${INPUT_DOCROOT:-/var/www/html}"
DOCROOT="${DOCROOT%/}"

read -p "  Senha root MySQL [Enter = auth socket]: " DB_ROOT_PASS
echo ""

# Gerar senha aleatória para o usuário interno do phpMyAdmin
PMA_PASS=$(openssl rand -base64 16 | tr -d '/+=')
BLOWFISH=$(openssl rand -base64 32 | tr -d '/+=')

# ── Instalar dependências PHP ─────────────────────────────────
step "Instalando dependências"
apt-get update -qq
DEBIAN_FRONTEND=noninteractive apt-get install -y -qq \
  php-mbstring php-zip php-gd php-json php-curl php-xml \
  php-mysqli php-mysqlnd \
  unzip wget curl 2>/dev/null || true
phpenmod mbstring 2>/dev/null || true
log "Dependências PHP instaladas"

# ── Download phpMyAdmin ───────────────────────────────────────
step "Baixando phpMyAdmin"
PMA_VERSION="5.2.1"
PMA_URL="https://files.phpmyadmin.net/phpMyAdmin/${PMA_VERSION}/phpMyAdmin-${PMA_VERSION}-all-languages.zip"
TMP_DIR=$(mktemp -d)

echo "  Baixando versão $PMA_VERSION..."
wget -q --show-progress "$PMA_URL" -O "$TMP_DIR/phpmyadmin.zip" || {
  warn "wget falhou, tentando curl..."
  curl -L -o "$TMP_DIR/phpmyadmin.zip" "$PMA_URL"
}
log "Download concluído"

# ── Extrair e instalar ────────────────────────────────────────
step "Instalando phpMyAdmin"
unzip -q "$TMP_DIR/phpmyadmin.zip" -d "$TMP_DIR/"
PMA_EXTRACTED="$TMP_DIR/phpMyAdmin-${PMA_VERSION}-all-languages"

INSTALL_PATH="$DOCROOT/$PMA_DIR"
rm -rf "$INSTALL_PATH"
mv "$PMA_EXTRACTED" "$INSTALL_PATH"
rm -rf "$TMP_DIR"
log "Extraído em $INSTALL_PATH"

# ── Criar config.inc.php ──────────────────────────────────────
step "Gerando configuração"
mkdir -p "$INSTALL_PATH/tmp"
chmod 777 "$INSTALL_PATH/tmp"

cat > "$INSTALL_PATH/config.inc.php" << CONFEOF
<?php
// phpMyAdmin Configuration
declare(strict_types=1);

// Chave de segurança (blowfish)
\$cfg['blowfish_secret'] = '${BLOWFISH}';

\$i = 0;
\$i++;

// Conexão com o servidor MySQL local
\$cfg['Servers'][\$i]['auth_type']       = 'cookie';
\$cfg['Servers'][\$i]['host']            = 'localhost';
\$cfg['Servers'][\$i]['compress']        = false;
\$cfg['Servers'][\$i]['AllowNoPassword'] = false;

// Pasta temporária
\$cfg['TempDir'] = __DIR__ . '/tmp/';

// Configurações de segurança
\$cfg['LoginCookieValidity']    = 1440;      // 24 minutos
\$cfg['SendErrorReports']       = 'never';
\$cfg['CheckConfigurationPermissions'] = false;

// Interface
\$cfg['DefaultLang']  = 'pt_BR';
\$cfg['ThemeDefault'] = 'pmahomme';
\$cfg['MaxRows']      = 50;
\$cfg['ShowAll']      = true;
\$cfg['MemoryLimit']  = '512M';
CONFEOF
log "config.inc.php criado"

# ── Criar usuário pma no MySQL (controle interno) ─────────────
step "Configurando MySQL"
[ -n "$DB_ROOT_PASS" ] && MYSQL="mysql -u root -p${DB_ROOT_PASS}" || MYSQL="mysql -u root"

$MYSQL << SQLEOF 2>/dev/null || warn "Usuário pma pode já existir (ignorando)"
CREATE USER IF NOT EXISTS 'pma'@'localhost' IDENTIFIED BY '${PMA_PASS}';
GRANT ALL PRIVILEGES ON \`phpmyadmin\`.* TO 'pma'@'localhost';
FLUSH PRIVILEGES;
SQLEOF
log "Usuário MySQL 'pma' configurado"

# ── Criar .htaccess de proteção extra ────────────────────────
step "Configurando segurança"

# Criar arquivo de proteção por IP (opcional — comentado por padrão)
cat > "$INSTALL_PATH/.htaccess" << HTEOF
# phpMyAdmin — Segurança básica
Options -Indexes

# Para restringir por IP, descomente e ajuste:
# <RequireAny>
#   Require ip 192.168.1.0/24
#   Require ip 127.0.0.1
# </RequireAny>

# Bloquear acesso a arquivos sensíveis
<FilesMatch "^(config\.inc\.php|README|LICENSE|ChangeLog)$">
    Require all denied
</FilesMatch>
HTEOF

# Criar alias Apache para a subpasta
ALIAS_CONF="/etc/apache2/conf-available/phpmyadmin.conf"
cat > "$ALIAS_CONF" << APACHEEOF
# phpMyAdmin
Alias /$PMA_DIR "$INSTALL_PATH"

<Directory "$INSTALL_PATH">
    Options +FollowSymLinks -Indexes
    AllowOverride All
    Require all granted

    <IfModule mod_php.c>
        php_admin_value upload_max_filesize 128M
        php_admin_value post_max_size 128M
        php_admin_value memory_limit 512M
        php_admin_value max_execution_time 600
    </IfModule>
</Directory>
APACHEEOF

a2enconf phpmyadmin 2>/dev/null
log "Alias /$PMA_DIR configurado"

# ── Garantir AllowOverride All ────────────────────────────────
MAIN_CONF="/etc/apache2/apache2.conf"
sed -i '/^<Directory \/var\/www\/>/,/^<\/Directory>/ s/AllowOverride None/AllowOverride All/' "$MAIN_CONF" || true

# ── Permissões ─────────────────────────────────────────────────
step "Configurando permissões"
chown -R www-data:www-data "$INSTALL_PATH"
chmod -R 755 "$INSTALL_PATH"
chmod 750 "$INSTALL_PATH/config.inc.php"
chmod 777 "$INSTALL_PATH/tmp"
log "Permissões configuradas"

# ── Reload Apache ──────────────────────────────────────────────
step "Recarregando Apache"
apache2ctl configtest 2>&1 | grep -q "Syntax OK" && \
  log "Apache: Syntax OK" || warn "Verifique a config manualmente"
systemctl reload apache2
log "Apache recarregado"

# ── Resumo final ──────────────────────────────────────────────
IP=$(hostname -I | awk '{print $1}')
echo ""
echo -e "  ╔═══════════════════════════════════════════════════════╗"
echo -e "  ║  ${GRN}${BLD}phpMyAdmin instalado com sucesso!${RST}"
echo -e "  ╠═══════════════════════════════════════════════════════╣"
echo -e "  ║  ${BLD}URL:${RST}      ${CYN}http://$IP/$PMA_DIR${RST}"
echo -e "  ║  ${BLD}Pasta:${RST}    $INSTALL_PATH"
echo -e "  ╠═══════════════════════════════════════════════════════╣"
echo -e "  ║  ${BLD}Como entrar:${RST}"
echo -e "  ║  • Usuário: ${YLW}root${RST} (ou qualquer usuário MySQL)"
echo -e "  ║  • Senha: ${YLW}sua senha MySQL${RST}"
echo -e "  ╠═══════════════════════════════════════════════════════╣"
echo -e "  ║  ${BLD}Usuários úteis no seu servidor:${RST}"
echo -e "  ║  • ${YLW}root${RST}       → acesso total"
echo -e "  ║  • ${YLW}phpexpert${RST}  → banco phpexpert"
echo -e "  ║  • ${YLW}gestao${RST}     → banco gestao"
echo -e "  ╠═══════════════════════════════════════════════════════╣"
echo -e "  ║  ${RED}⚠ SEGURANÇA:${RST} Em produção, restrinja o acesso"
echo -e "  ║  por IP editando: $INSTALL_PATH/.htaccess"
echo -e "  ╚═══════════════════════════════════════════════════════╝"
echo ""
