<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/layout.php';

Auth::start(); Auth::require();
$uid  = Auth::id();
$type = $_GET['type'] ?? '';

// ── FIX: serve download BEFORE any HTML output ───────────────
if (in_array($type, ['txt', 'html'])) {
    try {
        $path     = $type === 'txt' ? Exporter::txt($uid) : Exporter::html($uid);
        $filename = basename($path);
        $mime     = $type === 'txt' ? 'text/plain' : 'text/html';
        header("Content-Type: $mime; charset=utf-8");
        header("Content-Disposition: attachment; filename=\"$filename\"");
        header('Content-Length: ' . filesize($path));
        readfile($path);
        exit;
    } catch (Exception $e) {
        // Store error to show after page_start
        $exportError = 'Erro ao gerar export: ' . $e->getMessage();
    }
}

// Only reach here if not downloading
$prevExports = DB::all(
    'SELECT * FROM exports WHERE user_id=? ORDER BY created_at DESC LIMIT 20',
    [$uid]
);

page_start('Exportar Progresso');
?>
<aside class="sidebar" style="display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;padding:24px">
  <div style="font-size:3rem">⬇</div>
  <p style="color:var(--t3);font-size:.85rem;text-align:center;max-width:180px;line-height:1.6">
    Exporte seu progresso, notas e histórico para guardar offline.
  </p>
  <a href="<?= url('/') ?>" class="btn btn-sm" style="margin-top:8px">← Voltar à Trilha</a>
</aside>

<main class="main">
  <div class="hero">
    <div class="hero-eyebrow">Salve seu progresso externamente</div>
    <h1>Exportar Progresso</h1>
    <p class="hero-sub">
      Gere um relatório completo com seu progresso, histórico de sessões e notas pessoais.
      Disponível para download imediato.
    </p>
  </div>

  <div class="content">

    <?php if (!empty($exportError)): ?>
    <div class="flash flash-error"><?= htmlspecialchars($exportError) ?></div>
    <?php endif; ?>

    <div class="section-header"><h2>Formatos disponíveis</h2></div>
    <div class="export-grid">
      <a href="<?= url('/export.php?type=txt') ?>" class="export-card">
        <span class="export-icon">📄</span>
        <div class="export-title">Relatório .TXT</div>
        <div class="export-desc">
          Arquivo texto com seu progresso por capítulo, histórico de sessões
          e notas pessoais. Ideal para leitura rápida e backup.
        </div>
      </a>
      <a href="<?= url('/export.php?type=html') ?>" class="export-card">
        <span class="export-icon">🌐</span>
        <div class="export-title">Histórico .HTML</div>
        <div class="export-desc">
          Página HTML com design profissional, progresso por capítulo,
          histórico completo e anotações. Abre offline no navegador.
        </div>
      </a>
    </div>

    <div class="callout callout-info">
      <span class="callout-icon">💡</span>
      <div>
        Arquivos salvos em <code style="font-family:var(--ff-mono);color:var(--ora)"><?= htmlspecialchars(EXPORT_DIR) ?></code>.
        Exporte regularmente para manter um histórico externo do seu progresso.
      </div>
    </div>

    <?php if (!empty($prevExports)): ?>
    <div class="prev-exports">
      <div class="section-header"><h2>Exports anteriores</h2></div>
      <table class="hist-table">
        <thead>
          <tr><th>DATA</th><th>TIPO</th><th>ARQUIVO</th><th>AÇÃO</th></tr>
        </thead>
        <tbody>
          <?php foreach ($prevExports as $ex): ?>
          <tr>
            <td class="hist-ts"><?= htmlspecialchars($ex['created_at']) ?></td>
            <td><span class="tag <?= $ex['export_type']==='html' ? 'tag-blu' : 'tag-muted' ?>"><?= strtoupper($ex['export_type']) ?></span></td>
            <td class="text-mono" style="font-size:.82rem"><?= htmlspecialchars($ex['filename']) ?></td>
            <td><a href="<?= url('/export_download.php?file=' . urlencode($ex['filename'])) ?>" class="btn btn-sm">⬇ Baixar</a></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php endif; ?>

  </div>
</main>

<?php page_end(); ?>
