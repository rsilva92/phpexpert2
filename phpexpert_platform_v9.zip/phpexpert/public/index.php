<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/layout.php';

Auth::start();
Auth::require();

$uid      = Auth::id();
$bookData = require __DIR__ . '/../data/book_data.php';
$prog     = Progress::get($uid);
$lastSec  = History::last($uid);

// Compute total progress
$totalSecs = 0;
$totalDone = 0;
foreach ($bookData as $capNum => $cap) {
    $totalSecs += count($cap['sections']);
    foreach ($cap['sections'] as $si => $sec) {
        if (!empty($prog[$capNum . '_' . $si])) $totalDone++;
    }
}
$totalPct = $totalSecs > 0 ? round($totalDone / $totalSecs * 100) : 0;

function level(int $pct): string {
    if ($pct < 10)  return 'Iniciante';
    if ($pct < 25)  return 'Básico';
    if ($pct < 50)  return 'Intermediário';
    if ($pct < 75)  return 'Avançado';
    if ($pct < 95)  return 'Especialista';
    return '🏆 PHP Master';
}

$capTitles = [
    1 => 'Introdução ao PHP',
    2 => 'Fundamentos de OOP',
    3 => 'Do Estruturado à OOP',
    4 => 'Tópicos Especiais em OOP',
    5 => 'Persistência',
    6 => 'Apresentação e Controle',
    7 => 'Formulários e Listagens',
    8 => 'Criando uma Aplicação',
];
$capDescs = [
    1 => 'Tipos, operadores, estruturas de controle, funções, arrays e strings.',
    2 => 'Classes, herança, polimorfismo, encapsulamento e design patterns.',
    3 => 'Evolução em 7 níveis do procedural ao OOP com PDO.',
    4 => 'Exceções, métodos mágicos, XML, SPL, Traits, Namespaces e Composer.',
    5 => 'Active Record, Data Mapper, Repository Pattern e Query Object.',
    6 => 'MVC, Front Controller, Templates e componentes de UI.',
    7 => 'Formulários OO, campos tipados, validações e datagrids.',
    8 => 'Aplicação completa: vendas, login, relatórios e dashboard.',
];

page_start('Trilha de Estudos');

// Build a safe JS-embeddable map: cap -> [sec0, sec1, ...] with title+content
$jsBookMap = [];
foreach ($bookData as $capNum => $cap) {
    $jsBookMap[$capNum] = array_map(fn($s) => [
        'id'      => $s['id'],
        'title'   => $s['title'],
        'content' => $s['content'],
    ], $cap['sections']);
}
?>

<!-- ── Global JS vars ── -->
<script>
const BOOK_MAP = <?= json_encode($jsBookMap, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) ?>;
const APP_BASE = <?= json_encode(APP_BASE) ?>;
const INIT_DONE = <?= $totalDone ?>;
const INIT_TOTAL = <?= $totalSecs ?>;
</script>
<script>
document.addEventListener('DOMContentLoaded', () => {
  updateTopbarProgress(INIT_DONE, INIT_TOTAL);
});
</script>

<div style="display:contents">

<!-- ── SIDEBAR ──────────────────────────────────────────────── -->
<aside class="sidebar">
  <div class="sb-header">
    <div class="sb-label">
      <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>
      8 Capítulos · <?= array_sum(array_map(fn($c)=>count($c['sections']), $bookData)) ?> Seções
    </div>
    <div class="search-wrap">
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
      <input class="search-input" id="sbSearch" type="text" placeholder="Buscar seção...">
    </div>
  </div>

  <div class="sb-body">
    <?php foreach ($bookData as $capNum => $cap):
      $capDone = 0; $capTotal = count($cap['sections']);
      foreach ($cap['sections'] as $si => $sec) {
          if (!empty($prog[$capNum . '_' . $si])) $capDone++;
      }
      $isDone = $capDone === $capTotal;
    ?>
    <div class="cap-group">
      <button class="cap-btn <?= $isDone ? 'cap-done' : '' ?>"
              data-capbtn="<?= $capNum ?>"
              onclick="toggleCap(<?= $capNum ?>)">
        <span class="cap-num" data-capnum="<?= $capNum ?>"><?= $isDone ? '✓' : $capNum ?></span>
        <span class="cap-title" style="flex:1;text-align:left"><?= htmlspecialchars($cap['title']) ?></span>
        <svg class="cap-chevron" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
        <span class="cap-pct"><?= $capDone ?>/<?= $capTotal ?></span>
      </button>
      <div class="sec-list" id="sl-<?= $capNum ?>">
        <?php foreach ($cap['sections'] as $si => $sec):
          $done = !empty($prog[$capNum . '_' . $si]);
        ?>
        <div class="sec-row <?= $done ? 'sec-done' : '' ?>"
             data-cap="<?= $capNum ?>"
             data-sec="<?= $si ?>"
             data-title="<?= htmlspecialchars($sec['title'], ENT_QUOTES) ?>"
             onclick="openSectionByIndex(<?= $capNum ?>, <?= $si ?>)">
          <span class="sec-dot"></span>
          <span><?= htmlspecialchars($sec['title']) ?></span>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</aside>

<!-- ── MAIN ──────────────────────────────────────────────────── -->
<main class="main">

  <!-- Hero -->
  <div class="hero">
    <div class="hero-mono">&lt;?php</div>
    <div class="hero-eyebrow">PHP Programando com OO · <span>Pablo Dall'Oglio</span> · 4ª Edição · 600 páginas</div>
    <h1>Trilha Completa<br>para PHP Expert</h1>
    <p class="hero-sub">Conteúdo real do livro com explicações, exemplos e progresso. Marque seções, anote e exporte seu histórico a qualquer momento.</p>
    <div class="hero-tags">
      <span class="tag tag-ora">PHP 7.2+</span>
      <span class="tag tag-grn">OOP</span>
      <span class="tag tag-blu">Design Patterns</span>
      <span class="tag tag-muted"><?= $totalSecs ?> Seções</span>
      <span class="tag tag-ora">MVC · PDO</span>
      <span class="tag tag-muted">Composer · PSR</span>
    </div>
    <?php if ($lastSec): ?>
    <div style="margin-top:14px;padding:10px 14px;background:var(--ora-dim);border:1px solid var(--ora);border-radius:var(--radius-sm);font-size:.78rem;display:inline-flex;align-items:center;gap:8px">
      <span>🕐</span>
      <span>Última seção: <strong><?= htmlspecialchars($lastSec['sec_title']) ?></strong> — Cap.<?= $lastSec['chapter_id'] ?></span>
    </div>
    <?php endif; ?>
  </div>

  <div class="content">

    <!-- Stats -->
    <div class="stats-row">
      <div class="stat-card">
        <div class="stat-lbl">Seções Concluídas</div>
        <div class="stat-val" id="statDone"><?= $totalDone ?> <small>/ <?= $totalSecs ?></small></div>
      </div>
      <?php
        $capsDone = 0;
        foreach ($bookData as $capNum => $cap) {
            $cd = 0;
            foreach ($cap['sections'] as $si => $sec) {
                if (!empty($prog[$capNum.'_'.$si])) $cd++;
            }
            if ($cd === count($cap['sections'])) $capsDone++;
        }
      ?>
      <div class="stat-card">
        <div class="stat-lbl">Capítulos Completos</div>
        <div class="stat-val"><?= $capsDone ?> <small>/ 8</small></div>
      </div>
      <div class="stat-card">
        <div class="stat-lbl">Progresso Geral</div>
        <div class="stat-val"><?= $totalPct ?><small>%</small></div>
        <div class="stat-sub">
          <div style="height:3px;background:var(--bg-4);border-radius:2px;margin-top:6px">
            <div style="height:100%;width:<?= $totalPct ?>%;background:var(--ora);border-radius:2px"></div>
          </div>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-lbl">Nível Atual</div>
        <div class="stat-val" style="font-size:1rem;padding-top:4px"><?= level($totalPct) ?></div>
      </div>
    </div>

    <!-- Reader panel -->
    <div class="reader" id="reader">
      <div class="reader-head">
        <div class="reader-head-info">
          <h2 id="rTitle">Seção</h2>
          <p id="rCapLabel" class="text-mono text-muted">Capítulo</p>
        </div>
        <button class="close-btn" onclick="closeReader()">✕</button>
      </div>
      <div class="reader-tabs">
        <button class="r-tab on" data-tab="content" onclick="switchTab('content',this)">📖 Conteúdo</button>
        <button class="r-tab" data-tab="code"    onclick="switchTab('code',this)">{ } Código</button>
        <button class="r-tab" data-tab="notes"   onclick="switchTab('notes',this)">📝 Notas</button>
      </div>
      <div class="reader-body" id="rBody"></div>
    </div>

    <!-- Chapter cards -->
    <div class="section-header"><h2>Capítulos</h2></div>
    <div class="cap-grid">
      <?php foreach ($bookData as $capNum => $cap):
        $capDone  = 0; $capTotal = count($cap['sections']);
        foreach ($cap['sections'] as $si => $sec) {
            if (!empty($prog[$capNum . '_' . $si])) $capDone++;
        }
        $capPct   = $capTotal > 0 ? round($capDone / $capTotal * 100) : 0;
        $isDone   = $capPct === 100;
        $badgeCls = $isDone ? 'b-done' : ($capDone > 0 ? 'b-wip' : 'b-todo');
        $badgeTxt = $isDone ? 'Concluído' : ($capDone > 0 ? 'Em andamento' : 'Pendente');
      ?>
      <div class="cap-card <?= $isDone ? 'card-done' : '' ?>"
           data-card-cap="<?= $capNum ?>"
           onclick="toggleCap(<?= $capNum ?>); document.getElementById('sl-<?= $capNum ?>').scrollIntoView({behavior:'smooth',block:'nearest'})">
        <div class="cc-top">
          <span class="cc-num">CAPÍTULO <?= $capNum ?></span>
          <span class="cc-badge <?= $badgeCls ?>"><?= $badgeTxt ?></span>
        </div>
        <div class="cc-title"><?= htmlspecialchars($capTitles[$capNum]) ?></div>
        <div class="cc-desc"><?= htmlspecialchars($capDescs[$capNum]) ?></div>
        <div class="cc-prog">
          <div class="cc-track"><div class="cc-fill" style="width:<?= $capPct ?>%"></div></div>
          <span class="cc-pct"><?= $capDone ?>/<?= $capTotal ?></span>
        </div>
      </div>
      <?php endforeach; ?>
    </div>

    <!-- Quick actions -->
    <div class="section-header"><h2>Ações Rápidas</h2></div>
    <div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:24px">
      <a href="<?= url('/history.php') ?>" class="btn btn-primary">🕐 Ver Histórico</a>
      <a href="<?= url('/export.php?type=txt') ?>"  class="btn">📄 Exportar .TXT</a>
      <a href="<?= url('/export.php?type=html') ?>" class="btn">🌐 Exportar .HTML</a>
      <a href="<?= url('/export.php') ?>" class="btn">⬇ Todos os Exports</a>
    </div>

  </div><!-- /content -->
</main>

</div>



<?php page_end(); ?>
