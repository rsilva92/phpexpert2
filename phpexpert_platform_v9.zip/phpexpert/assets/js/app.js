'use strict';

// ── PHP Syntax Highlighter ───────────────────────────────────
function hlPHP(raw) {
  const esc = raw
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  return esc
    .replace(/(\/\/[^\n]*)|(#[^\n]*)/g, '<span class="cmt">$1$2</span>')
    .replace(/('(?:[^'\\]|\\.)*'|"(?:[^"\\]|\\.)*")/g, '<span class="str">$1</span>')
    .replace(/\b(class|extends|implements|interface|abstract|final|trait|namespace|use|function|return|new|echo|print|var_dump|print_r|if|else|elseif|foreach|for|while|do|switch|case|break|continue|try|catch|throw|require|include|require_once|include_once|public|private|protected|static|const|null|true|false|void|self|parent|match|fn)\b/g,
      '<span class="kw">$1</span>')
    .replace(/\b(int|string|float|bool|array|object|callable|iterable|mixed)\b/g,
      '<span class="type">$1</span>')
    .replace(/(\$[a-zA-Z_][a-zA-Z0-9_]*)/g, '<span class="var">$1</span>')
    .replace(/\b([a-zA-Z_][a-zA-Z0-9_]*)\s*(?=\()/g, '<span class="fn">$1</span>')
    .replace(/\b(-?\d+\.?\d*)\b/g, '<span class="num">$1</span>');
}

function makeCodeBlock(code, label='PHP') {
  const id = 'cb' + Math.random().toString(36).slice(2,8);
  return `<div class="code-block">
    <div class="code-header">
      <div class="code-dots"><span></span><span></span><span></span></div>
      <span class="code-lang">${label}</span>
      <button class="copy-btn" onclick="copyCode('${id}',this)">copiar</button>
    </div>
    <pre id="${id}">${hlPHP(code)}</pre>
  </div>`;
}

function copyCode(id, btn) {
  const text = document.getElementById(id)?.innerText || '';
  navigator.clipboard.writeText(text).then(() => {
    btn.textContent = 'copiado!';
    btn.classList.add('copied');
    setTimeout(() => { btn.textContent = 'copiar'; btn.classList.remove('copied'); }, 2000);
  });
}

// ── Progress bar ─────────────────────────────────────────────
function updateTopbarProgress(done, total) {
  const pct = total > 0 ? Math.round(done/total*100) : 0;
  const fill = document.getElementById('tbProgFill');
  const pctEl = document.getElementById('tbPct');
  if (fill)  fill.style.width = pct + '%';
  if (pctEl) pctEl.textContent = pct + '%';
}

// ── AJAX ─────────────────────────────────────────────────────
async function api(endpoint, data={}) {
  // Build correct API URL respecting APP_BASE (same logic as PHP url())
  const base = (typeof APP_BASE !== 'undefined' && APP_BASE !== '')
    ? APP_BASE.replace(/\/$/, '')
    : '';
  const apiUrl = base + '/api.php';
  try {
    const res = await fetch(apiUrl, {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({action: endpoint, ...data})
    });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    return res.json();
  } catch (e) {
    console.error('API error:', endpoint, e);
    return {};
  }
}

// ── Content renderer ─────────────────────────────────────────
// Splits content into prose paragraphs and PHP code blocks
function renderContent(raw) {
  if (!raw) return '<p class="text-muted">Conteúdo não disponível.</p>';

  // Split on PHP code blocks
  const CODE_RE = /<\?php[\s\S]*?(?=\n\n(?!\s*[\$\/\*#])|$)/g;
  let html = '';
  let lastIndex = 0;
  let match;

  CODE_RE.lastIndex = 0;
  while ((match = CODE_RE.exec(raw)) !== null) {
    // Prose before this code block
    const prose = raw.slice(lastIndex, match.index).trim();
    if (prose) html += renderProse(prose);
    // Code block
    html += makeCodeBlock(match[0].trim());
    lastIndex = match.index + match[0].length;
  }
  // Remaining prose after last code block
  const tail = raw.slice(lastIndex).trim();
  if (tail) html += renderProse(tail);

  return html || '<p class="text-muted">Sem conteúdo.</p>';
}

function renderProse(text) {
  // Split into paragraphs on double newline
  const paras = text.split(/\n\n+/);
  return paras.map(p => {
    p = p.trim();
    if (!p) return '';
    // Bullet list (lines starting with • or -)
    if (/^[•\-]\s/.test(p)) {
      const items = p.split('\n')
        .map(l => l.replace(/^[•\-]\s*/, '').trim())
        .filter(Boolean);
      return '<ul>' + items.map(l => `<li>${escHtml(l)}</li>`).join('') + '</ul>';
    }
    // Regular paragraph — single newlines become spaces (already done in PHP)
    return `<p>${escHtml(p)}</p>`;
  }).join('');
}

// ── Section reader ────────────────────────────────────────────
let currentSec = null;
let currentTab = 'content';

// Safe: looks up data from BOOK_MAP (JSON injected in <script> tag)
function openSectionByIndex(chapId, secIdx) {
  const cap = (typeof BOOK_MAP !== 'undefined') ? BOOK_MAP[chapId] : null;
  if (!cap || !cap[secIdx]) {
    console.error('BOOK_MAP missing cap', chapId, 'sec', secIdx);
    return;
  }
  const sec = cap[secIdx];
  openSection(chapId, secIdx, sec.title, sec.content);
}

function openSection(chapId, secIdx, title, content) {
  currentSec = {chapId, secIdx, title, content};

  document.getElementById('rTitle').textContent = title;
  document.getElementById('rCapLabel').textContent = `Capítulo ${chapId}`;

  const reader = document.getElementById('reader');
  reader.classList.add('open');

  // Reset to content tab
  document.querySelectorAll('.r-tab').forEach(t => t.classList.remove('on'));
  const contentTab = document.querySelector('.r-tab[data-tab="content"]');
  if (contentTab) contentTab.classList.add('on');
  currentTab = 'content';

  renderReaderTab();

  // Record history via AJAX
  api('history', {cap: chapId, sec: secIdx, title});

  // Highlight in sidebar
  document.querySelectorAll('.sec-row').forEach(r => r.classList.remove('sec-active'));
  const row = document.querySelector(`.sec-row[data-cap="${chapId}"][data-sec="${secIdx}"]`);
  if (row) row.classList.add('sec-active');

  reader.scrollIntoView({behavior:'smooth', block:'nearest'});
}

function switchTab(tab, el) {
  if (!currentSec) return;
  currentTab = tab;
  document.querySelectorAll('.r-tab').forEach(t => t.classList.remove('on'));
  if (el) el.classList.add('on');
  renderReaderTab();
}

function renderReaderTab() {
  if (!currentSec) return;
  const {chapId, secIdx, content} = currentSec;
  const body = document.getElementById('rBody');

  if (currentTab === 'content') {
    let html = '<div class="prose">' + renderContent(content) + '</div>';
    html += `<div class="btn-row">
      <button class="btn btn-sm" onclick="markDone(${chapId},${secIdx},false)">✗ Desmarcar</button>
      <button class="btn btn-success btn-sm" onclick="markDone(${chapId},${secIdx},true)">✓ Seção Concluída</button>
    </div>`;
    body.innerHTML = html;

  } else if (currentTab === 'code') {
    const codes = [];
    const CODE_RE = /<\?php[\s\S]*?(?=\n\n(?!\s*[\$\/\*#])|$)/g;
    let m;
    while ((m = CODE_RE.exec(content)) !== null) {
      codes.push(m[0].trim());
    }
    if (codes.length === 0) {
      body.innerHTML = `<div class="callout callout-info">
        <span class="callout-icon">ℹ️</span>
        <div>Esta seção não possui exemplos de código isolados. O conteúdo está na aba <strong>Conteúdo</strong>.</div>
      </div>`;
    } else {
      body.innerHTML = codes.map((c, i) => makeCodeBlock(c, `Exemplo ${i + 1}`)).join('');
    }

  } else if (currentTab === 'notes') {
    api('get_note', {cap: chapId, sec: secIdx}).then(r => {
      body.innerHTML = `
        <p class="text-muted text-mono" style="font-size:.72rem;margin-bottom:8px">
          Notas — ${escHtml(currentSec.title)}
        </p>
        <textarea class="notes-ta" id="noteTa"
          placeholder="Escreva resumos, dúvidas, insights...">${escHtml(r.note||'')}</textarea>
        <div class="callout callout-success" style="margin-top:8px">
          <span class="callout-icon">💡</span>
          <div>Escrever com suas próprias palavras acelera o aprendizado. Salvo automaticamente.</div>
        </div>`;
      document.getElementById('noteTa')?.addEventListener('input',
        debounce(e => api('save_note', {cap: chapId, sec: secIdx, text: e.target.value}), 600));
    });
  }
}

function closeReader() {
  document.getElementById('reader').classList.remove('open');
  currentSec = null;
  document.querySelectorAll('.sec-row').forEach(r => r.classList.remove('sec-active'));
}

// ── Mark done ─────────────────────────────────────────────────
function markDone(cap, sec, done) {
  api('toggle', {cap, sec, done}).then(r => {
    const row = document.querySelector(`.sec-row[data-cap="${cap}"][data-sec="${sec}"]`);
    if (row) row.classList.toggle('sec-done', done);
    refreshCapCard(cap);
    updateTopbarProgress(r.total_done, r.total_secs);
  });
}

function refreshCapCard(cap) {
  api('cap_progress', {cap}).then(r => {
    const card = document.querySelector(`[data-card-cap="${cap}"]`);
    if (!card) return;
    const fill  = card.querySelector('.cc-fill');
    const pct   = card.querySelector('.cc-pct');
    const badge = card.querySelector('.cc-badge');
    if (fill)  fill.style.width = r.pct + '%';
    if (pct)   pct.textContent = `${r.done}/${r.total}`;
    if (badge) {
      badge.className = 'cc-badge ' + (r.pct===100?'b-done':r.done>0?'b-wip':'b-todo');
      badge.textContent = r.pct===100?'Concluído':r.done>0?'Em andamento':'Pendente';
    }
    card.classList.toggle('card-done', r.pct===100);
    const capNum = document.querySelector(`[data-capnum="${cap}"]`);
    if (capNum) capNum.textContent = r.pct===100 ? '✓' : cap;
    const capEl = document.querySelector(`[data-capbtn="${cap}"]`);
    if (capEl) capEl.classList.toggle('cap-done', r.pct===100);
  });
}

// ── Sidebar ───────────────────────────────────────────────────
function toggleCap(id) {
  const list = document.getElementById('sl-'+id);
  const btn  = document.querySelector(`[data-capbtn="${id}"]`);
  if (!list || !btn) return;
  const isOpen = list.classList.toggle('open');
  btn.classList.toggle('cap-open', isOpen);
}

// ── Search ────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  const srch = document.getElementById('sbSearch');
  if (srch) {
    srch.addEventListener('input', () => {
      const q = srch.value.toLowerCase().trim();
      document.querySelectorAll('.cap-group').forEach((grp, i) => {
        const rows = grp.querySelectorAll('.sec-row');
        let anyMatch = false;
        rows.forEach(row => {
          const text = (row.dataset.title || row.textContent).toLowerCase();
          const match = !q || text.includes(q);
          row.style.display = match ? '' : 'none';
          if (match) anyMatch = true;
        });
        if (q && anyMatch) {
          grp.querySelector('.sec-list')?.classList.add('open');
          grp.querySelector('.cap-btn')?.classList.add('cap-open');
        }
        grp.style.display = (!q || anyMatch) ? '' : 'none';
      });
    });
  }

  // Inject topbar progress bar
  const tbSpacer = document.querySelector('.topbar .tb-spacer');
  if (tbSpacer && document.getElementById('_initDone') === null) {
    const prog = document.createElement('div');
    prog.className = 'tb-prog';
    prog.innerHTML = `
      <div class="tb-prog-track">
        <div class="tb-prog-fill" id="tbProgFill" style="width:0%"></div>
      </div>
      <span class="tb-pct" id="tbPct">0%</span>`;
    tbSpacer.parentNode.insertBefore(prog, tbSpacer);
  }
});

// ── Utilities ─────────────────────────────────────────────────
function escHtml(s) {
  return String(s)
    .replace(/&/g,'&amp;')
    .replace(/</g,'&lt;')
    .replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;');
}

function debounce(fn, ms) {
  let t;
  return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
}

// Flash auto-dismiss
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.flash').forEach(el => {
    setTimeout(() => { el.style.transition='opacity .5s'; el.style.opacity='0'; }, 3000);
    setTimeout(() => el.remove(), 3500);
  });
});
