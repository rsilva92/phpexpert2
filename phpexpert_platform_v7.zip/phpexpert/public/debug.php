<?php
/**
 * PHP Expert — Diagnóstico de Instalação
 * ATENÇÃO: DELETE este arquivo após confirmar que tudo funciona!
 * Acesse: http://IP/phpexpert/debug.php
 */

// Bloquear acesso externo — só localhost ou IP da VPS
// (remova esta proteção se precisar acessar remotamente durante debug)

header('Content-Type: text/html; charset=utf-8');

function ok(string $msg): void  { echo "<div class='ok'>✓ $msg</div>"; }
function err(string $msg): void { echo "<div class='err'>✗ $msg</div>"; }
function warn(string $msg): void { echo "<div class='warn'>! $msg</div>"; }
function info(string $msg): void { echo "<div class='info'>ℹ $msg</div>"; }
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<title>PHP Expert — Debug</title>
<style>
body { font-family: 'JetBrains Mono', monospace; background: #0d0d0d; color: #e8e8e8;
       padding: 2rem; font-size: 14px; }
h1   { color: #d97757; margin-bottom: 1.5rem; }
h2   { color: #a8a8a8; font-size: .85rem; letter-spacing: 2px; text-transform: uppercase;
       margin: 1.5rem 0 .5rem; border-bottom: 1px solid #222; padding-bottom: .4rem; }
.ok   { color: #4ade80; padding: 4px 0; }
.err  { color: #f87171; padding: 4px 0; font-weight: bold; }
.warn { color: #fbbf24; padding: 4px 0; }
.info { color: #60a5fa; padding: 4px 0; }
.box  { background: #161616; border: 1px solid #222; border-radius: 8px;
        padding: 1rem; margin-top: 1.5rem; }
pre   { background: #0a0a0a; padding: 1rem; border-radius: 6px;
        border: 1px solid #222; overflow-x: auto; color: #a8a8a8; font-size: .8rem; }
.del  { margin-top: 2rem; padding: 1rem; background: rgba(248,113,113,.1);
        border: 1px solid #f87171; border-radius: 8px; color: #f87171; font-size: .82rem; }
</style>
</head>
<body>
<h1>⚡ PHP Expert — Diagnóstico</h1>

<h2>1. PHP</h2>
<?php
$phpVer = phpversion();
if (version_compare($phpVer, '7.4', '>=')) {
    ok("PHP $phpVer");
} else {
    err("PHP $phpVer — precisa de 7.4+");
}

$exts = ['pdo', 'pdo_mysql', 'mbstring', 'json', 'session'];
foreach ($exts as $ext) {
    if (extension_loaded($ext)) ok("Extensão: $ext");
    else err("Extensão FALTANDO: $ext — instale php-$ext");
}
?>

<h2>2. Arquivos do projeto</h2>
<?php
$base = __DIR__ . '/..';
$files = [
    'includes/config.php',
    'includes/db.php',
    'includes/layout.php',
    'data/book_data.php',
    'exports/',
    'public/assets/css/app.css',
    'public/assets/js/app.js',
];
foreach ($files as $f) {
    $path = $base . '/' . $f;
    if (file_exists($path)) ok("Existe: $f");
    else err("NÃO ENCONTRADO: $f");
}

if (is_writable($base . '/exports')) ok("exports/ tem permissão de escrita");
else err("exports/ não tem permissão de escrita — rode: chmod 775 " . realpath($base.'/exports'));
?>

<h2>3. Config (APP_BASE e url())</h2>
<?php
require_once __DIR__ . '/../includes/config.php';
info("APP_BASE = '" . APP_BASE . "'");
info("APP_URL  = '" . APP_URL . "'");
info("url('/')          = '" . url('/') . "'");
info("url('/login.php') = '" . url('/login.php') . "'");
info("EXPORT_DIR = " . EXPORT_DIR);
?>

<h2>4. Banco de dados MySQL</h2>
<?php
$dsn = sprintf('mysql:host=%s;dbname=%s;charset=%s', DB_HOST, DB_NAME, DB_CHARSET);
try {
    $pdo = new PDO($dsn, DB_USER, DB_PASS, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    ok("Conexão com MySQL OK");
    ok("Banco: " . DB_NAME . " @ " . DB_HOST);

    $tables = ['users','progress','notes','history','exports'];
    foreach ($tables as $t) {
        $r = $pdo->query("SHOW TABLES LIKE '$t'")->fetchAll();
        if ($r) ok("Tabela '$t' existe");
        else err("Tabela '$t' NÃO EXISTE — rode: mysql phpexpert < install/schema.sql");
    }
} catch (PDOException $e) {
    err("Falha ao conectar: " . $e->getMessage());
    warn("Verifique includes/config.php: DB_HOST, DB_NAME, DB_USER, DB_PASS");
}
?>

<h2>5. Apache / .htaccess</h2>
<?php
info("REQUEST_URI: " . $_SERVER['REQUEST_URI']);
info("SCRIPT_NAME: " . $_SERVER['SCRIPT_NAME']);
info("DOCUMENT_ROOT: " . $_SERVER['DOCUMENT_ROOT']);
info("PHP_SELF: " . $_SERVER['PHP_SELF']);

$htaccess = __DIR__ . '/.htaccess';
if (file_exists($htaccess)) {
    ok(".htaccess existe");
    $content = file_get_contents($htaccess);
    if (preg_match('/RewriteBase\s+(.+)/', $content, $m)) {
        ok("RewriteBase: " . trim($m[1]));
    } else {
        warn("RewriteBase não encontrado no .htaccess");
    }
} else {
    err(".htaccess não encontrado em " . $htaccess);
}
?>

<h2>6. Sessão PHP</h2>
<?php
session_start();
$_SESSION['test'] = 'ok';
if (isset($_SESSION['test'])) ok("Sessões funcionando");
else err("Sessões não funcionam — verifique session.save_path");
?>

<div class="del">
  ⚠️ <strong>IMPORTANTE:</strong> Delete ou proteja este arquivo após o diagnóstico!<br>
  <code>rm /var/www/html/phpexpert/public/debug.php</code>
</div>

</body>
</html>
