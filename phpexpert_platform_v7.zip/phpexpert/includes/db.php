<?php
// includes/db.php — PDO singleton + classes de negócio

class DB {
    private static ?PDO $pdo = null;

    public static function get(): PDO {
        if (self::$pdo === null) {
            $dsn = sprintf('mysql:host=%s;dbname=%s;charset=%s',
                DB_HOST, DB_NAME, DB_CHARSET);
            try {
                self::$pdo = new PDO($dsn, DB_USER, DB_PASS, [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES   => false,
                ]);
            } catch (PDOException $e) {
                // Mostra erro amigável sem expor credenciais
                http_response_code(500);
                echo '<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8">
                <title>Erro de conexão</title>
                <style>body{font-family:monospace;background:#0d0d0d;color:#e8e8e8;
                display:flex;align-items:center;justify-content:center;height:100vh;margin:0}
                .box{background:#161616;border:1px solid #d97757;border-radius:10px;
                padding:2rem;max-width:480px;text-align:center}
                h2{color:#d97757;margin-bottom:1rem}p{color:#a8a8a8;line-height:1.6}
                code{background:#222;padding:2px 6px;border-radius:3px;color:#fbbf24}
                </style></head><body><div class="box">
                <h2>⚠ Erro de conexão com o banco</h2>
                <p>Não foi possível conectar ao MySQL.<br>
                Verifique o arquivo <code>includes/config.php</code>:<br>
                DB_HOST, DB_NAME, DB_USER e DB_PASS.</p>
                <p style="margin-top:1rem;font-size:.8rem;color:#555">
                ' . htmlspecialchars($e->getMessage()) . '</p>
                </div></body></html>';
                exit;
            }
        }
        return self::$pdo;
    }

    public static function run(string $sql, array $params = []): PDOStatement {
        $stmt = self::get()->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }

    public static function one(string $sql, array $params = []): ?array {
        return self::run($sql, $params)->fetch() ?: null;
    }

    public static function all(string $sql, array $params = []): array {
        return self::run($sql, $params)->fetchAll();
    }

    public static function insert(string $sql, array $params = []): int {
        self::run($sql, $params);
        return (int) self::get()->lastInsertId();
    }
}

// ── Auth ─────────────────────────────────────────────────────
class Auth {
    public static function start(): void {
        if (session_status() === PHP_SESSION_NONE) {
            session_set_cookie_params([
                'lifetime' => SESSION_LIFETIME,
                'path'     => '/',
                'httponly' => true,
                'samesite' => 'Lax',
            ]);
            session_start();
        }
    }

    public static function user(): ?array {
        self::start();
        return $_SESSION['user'] ?? null;
    }

    public static function id(): ?int {
        return self::user()['id'] ?? null;
    }

    public static function require(): void {
        if (!self::id()) {
            header('Location: ' . url('/login.php'));
            exit;
        }
    }

    public static function login(string $username, string $password): bool {
        $user = DB::one('SELECT * FROM users WHERE username = ?', [$username]);
        if ($user && password_verify($password, $user['password'])) {
            self::start();
            $_SESSION['user'] = ['id' => $user['id'], 'username' => $user['username']];
            return true;
        }
        return false;
    }

    public static function register(string $username, string $password, string $email = ''): bool {
        $exists = DB::one('SELECT id FROM users WHERE username = ?', [$username]);
        if ($exists) return false;
        DB::insert(
            'INSERT INTO users (username, password, email) VALUES (?,?,?)',
            [$username, password_hash($password, PASSWORD_BCRYPT), $email]
        );
        return true;
    }

    public static function logout(): void {
        self::start();
        session_destroy();
        header('Location: ' . url('/login.php'));
        exit;
    }
}

// ── Progress ──────────────────────────────────────────────────
class Progress {
    public static function get(int $userId): array {
        $rows = DB::all(
            'SELECT chapter_id, section_idx, done FROM progress WHERE user_id = ?',
            [$userId]
        );
        $map = [];
        foreach ($rows as $r) {
            $map[$r['chapter_id'] . '_' . $r['section_idx']] = (bool)$r['done'];
        }
        return $map;
    }

    public static function toggle(int $userId, int $cap, int $sec, bool $done): void {
        DB::run(
            'INSERT INTO progress (user_id, chapter_id, section_idx, done)
             VALUES (?,?,?,?)
             ON DUPLICATE KEY UPDATE done=?, updated_at=NOW()',
            [$userId, $cap, $sec, $done, $done]
        );
    }
}

// ── Notes ─────────────────────────────────────────────────────
class Notes {
    public static function get(int $userId): array {
        $rows = DB::all(
            'SELECT chapter_id, section_idx, note_text FROM notes WHERE user_id = ?',
            [$userId]
        );
        $map = [];
        foreach ($rows as $r) {
            $map[$r['chapter_id'] . '_' . $r['section_idx']] = $r['note_text'];
        }
        return $map;
    }

    public static function save(int $userId, int $cap, int $sec, string $text): void {
        DB::run(
            'INSERT INTO notes (user_id, chapter_id, section_idx, note_text)
             VALUES (?,?,?,?)
             ON DUPLICATE KEY UPDATE note_text=?, updated_at=NOW()',
            [$userId, $cap, $sec, $text, $text]
        );
    }

    public static function getOne(int $userId, int $cap, int $sec): string {
        $r = DB::one(
            'SELECT note_text FROM notes WHERE user_id=? AND chapter_id=? AND section_idx=?',
            [$userId, $cap, $sec]
        );
        return $r['note_text'] ?? '';
    }
}

// ── History ───────────────────────────────────────────────────
class History {
    public static function record(int $userId, int $cap, int $sec, string $title): void {
        DB::run(
            'INSERT INTO history (user_id, chapter_id, section_idx, sec_title) VALUES (?,?,?,?)',
            [$userId, $cap, $sec, $title]
        );
    }

    public static function recent(int $userId, int $limit = 100): array {
        return DB::all(
            'SELECT * FROM history WHERE user_id=? ORDER BY viewed_at DESC LIMIT ?',
            [$userId, $limit]
        );
    }

    public static function last(int $userId): ?array {
        return DB::one(
            'SELECT * FROM history WHERE user_id=? ORDER BY viewed_at DESC LIMIT 1',
            [$userId]
        );
    }
}

// ── Exporter ──────────────────────────────────────────────────
class Exporter {

    public static function level(int $pct): string {
        if ($pct < 10)  return 'Iniciante';
        if ($pct < 25)  return 'Básico';
        if ($pct < 50)  return 'Intermediário';
        if ($pct < 75)  return 'Avançado';
        if ($pct < 95)  return 'Especialista';
        return '🏆 PHP Master';
    }

    public static function txt(int $userId): string {
        $bookData = require __DIR__ . '/../data/book_data.php';
        $prog  = Progress::get($userId);
        $notes = Notes::get($userId);
        $hist  = History::recent($userId, 50);
        $user  = Auth::user();

        $totalSecs = 0;
        foreach ($bookData as $cap) $totalSecs += count($cap['sections']);
        $doneSecs  = count(array_filter($prog));
        $pct       = $totalSecs > 0 ? round($doneSecs / $totalSecs * 100) : 0;

        $out  = "=======================================================\n";
        $out .= "  PHP EXPERT — RELATÓRIO DE PROGRESSO\n";
        $out .= "  PHP Programando com Orientação a Objetos\n";
        $out .= "  Pablo Dall'Oglio — 4ª Edição\n";
        $out .= "=======================================================\n\n";
        $out .= "Usuário  : " . ($user['username'] ?? '-') . "\n";
        $out .= "Gerado   : " . date('d/m/Y H:i:s') . "\n";
        $out .= "Progresso: $doneSecs / $totalSecs seções ($pct%)\n\n";

        foreach ($bookData as $capNum => $cap) {
            $cd = 0; $ct = count($cap['sections']);
            foreach ($cap['sections'] as $si => $sec) {
                if (!empty($prog[$capNum . '_' . $si])) $cd++;
            }
            $cp  = $ct > 0 ? round($cd / $ct * 100) : 0;
            $bar = str_repeat('█', (int)($cp / 5)) . str_repeat('░', 20 - (int)($cp / 5));
            $out .= "\nCap. $capNum — {$cap['title']}\n";
            $out .= "  [$bar] $cp% ($cd/$ct)\n";
            foreach ($cap['sections'] as $si => $sec) {
                $done = !empty($prog[$capNum . '_' . $si]) ? '[✓]' : '[ ]';
                $out .= "  $done {$sec['id']} — {$sec['title']}\n";
            }
        }

        $out .= "\n-------------------------------------------------------\n";
        $out .= "  HISTÓRICO (últimas 50 sessões)\n";
        $out .= "-------------------------------------------------------\n";
        if (empty($hist)) {
            $out .= "  Nenhuma sessão registrada.\n";
        } else {
            foreach ($hist as $h) {
                $out .= "  {$h['viewed_at']} — Cap.{$h['chapter_id']}: {$h['sec_title']}\n";
            }
        }

        $noteEntries = array_filter($notes);
        if (!empty($noteEntries)) {
            $out .= "\n-------------------------------------------------------\n";
            $out .= "  MINHAS NOTAS\n";
            $out .= "-------------------------------------------------------\n";
            foreach ($noteEntries as $key => $text) {
                [$cap, $sec] = explode('_', $key);
                $title = $bookData[$cap]['sections'][$sec]['title'] ?? "Seção $key";
                $out .= "\n>> $title\n" . wordwrap($text, 70, "\n   ", true) . "\n";
            }
        }

        $out .= "\n=======================================================\n";

        if (!is_dir(EXPORT_DIR)) mkdir(EXPORT_DIR, 0775, true);
        $filename = 'progresso_' . date('Y-m-d_His') . '.txt';
        $path = EXPORT_DIR . $filename;
        file_put_contents($path, $out);
        DB::run('INSERT INTO exports (user_id, export_type, filename) VALUES (?,?,?)',
            [$userId, 'txt', $filename]);
        return $path;
    }

    public static function html(int $userId): string {
        $bookData = require __DIR__ . '/../data/book_data.php';
        $prog  = Progress::get($userId);
        $notes = Notes::get($userId);
        $hist  = History::recent($userId, 100);
        $user  = Auth::user();

        $totalSecs = 0;
        foreach ($bookData as $cap) $totalSecs += count($cap['sections']);
        $doneSecs  = count(array_filter($prog));
        $pct       = $totalSecs > 0 ? round($doneSecs / $totalSecs * 100) : 0;

        $capsHtml = '';
        foreach ($bookData as $capNum => $cap) {
            $cd = 0; $ct = count($cap['sections']);
            foreach ($cap['sections'] as $si => $sec) {
                if (!empty($prog[$capNum . '_' . $si])) $cd++;
            }
            $cp = $ct > 0 ? round($cd / $ct * 100) : 0;
            $secsHtml = '';
            foreach ($cap['sections'] as $si => $sec) {
                $done  = !empty($prog[$capNum . '_' . $si]);
                $color = $done ? '#4ade80' : '#555';
                $icon  = $done ? '✓' : '○';
                $secsHtml .= "<li style='color:$color;margin:.2rem 0;font-size:.8rem'>$icon "
                    . htmlspecialchars($sec['title']) . "</li>";
            }
            $bc = $cp === 100 ? '#4ade80' : '#d97757';
            $capsHtml .= "<div style='background:#161616;border:1px solid #222;border-radius:10px;
                padding:1.2rem;margin-bottom:.9rem'>
              <div style='display:flex;justify-content:space-between;align-items:center;margin-bottom:.6rem'>
                <h3 style='color:#e8e8e8;font-size:.9rem'>Cap. $capNum — " . htmlspecialchars($cap['title']) . "</h3>
                <span style='font-family:monospace;font-size:.75rem;color:$bc'>$cp% ($cd/$ct)</span>
              </div>
              <div style='height:3px;background:#222;border-radius:2px;margin-bottom:.8rem'>
                <div style='height:100%;width:{$cp}%;background:$bc;border-radius:2px'></div>
              </div>
              <ul style='list-style:none;padding:0'>$secsHtml</ul>
            </div>";
        }

        $histRows = '';
        foreach ($hist as $h) {
            $histRows .= "<tr>
              <td style='padding:.35rem .75rem;color:#666;font-size:.72rem;font-family:monospace'>"
                . htmlspecialchars($h['viewed_at']) . "</td>
              <td style='padding:.35rem .75rem;color:#d97757;font-size:.75rem'>Cap. {$h['chapter_id']}</td>
              <td style='padding:.35rem .75rem;color:#a5b4fc;font-size:.72rem;font-family:monospace'>"
                . htmlspecialchars($h['sec_title']) . "</td></tr>";
        }
        if (!$histRows) $histRows = "<tr><td colspan='3' style='padding:1rem;text-align:center;color:#555;font-size:.8rem'>Sem sessões</td></tr>";

        $notesHtml = '';
        foreach (array_filter($notes) as $key => $text) {
            [$cap, $sec] = explode('_', $key);
            $title = $bookData[$cap]['sections'][$sec]['title'] ?? "Seção $key";
            $notesHtml .= "<div style='background:#0d0d0d;border:1px solid #222;border-radius:8px;
                padding:1rem;margin-bottom:.75rem'>
              <div style='font-size:.72rem;color:#d97757;font-family:monospace;margin-bottom:.5rem'>"
                . htmlspecialchars($title) . "</div>
              <div style='font-size:.82rem;color:#a8a8a8;white-space:pre-wrap;line-height:1.6'>"
                . htmlspecialchars($text) . "</div></div>";
        }

        $username = htmlspecialchars($user['username'] ?? '-');
        $date     = date('d/m/Y \à\s H:i');

        $html = "<!DOCTYPE html><html lang='pt-BR'><head>
<meta charset='UTF-8'>
<title>PHP Expert — Histórico " . date('Y-m-d') . "</title>
<link href='https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600&family=Geist:wght@400;600;700;800&display=swap' rel='stylesheet'>
</head>
<body style='background:#0d0d0d;color:#e8e8e8;font-family:Geist,sans-serif;margin:0;padding:2rem'>
<div style='max-width:860px;margin:0 auto'>
<div style='display:flex;align-items:center;gap:12px;margin-bottom:2rem;padding-bottom:1.5rem;border-bottom:1px solid #1c1c1c'>
  <div style='width:36px;height:36px;background:#d97757;border-radius:8px;display:flex;align-items:center;justify-content:center;font-family:monospace;font-size:.6rem;font-weight:700;color:#fff'>&lt;?php</div>
  <div>
    <h1 style='font-size:1.4rem;font-weight:800;background:linear-gradient(135deg,#e8e8e8,#d97757);-webkit-background-clip:text;-webkit-text-fill-color:transparent'>PHP Expert — Histórico</h1>
    <p style='color:#555;font-size:.78rem;font-family:monospace'>Usuário: $username · $date</p>
  </div>
</div>
<div style='display:grid;grid-template-columns:repeat(3,1fr);gap:1rem;margin-bottom:2rem'>
  <div style='background:#111;border:1px solid #1c1c1c;border-radius:10px;padding:1rem;position:relative;overflow:hidden'>
    <div style='position:absolute;top:0;left:0;right:0;height:2px;background:#d97757'></div>
    <div style='font-size:.6rem;letter-spacing:2px;text-transform:uppercase;color:#555;font-family:monospace;margin-bottom:.4rem'>PROGRESSO</div>
    <div style='font-size:2rem;font-weight:800'>$pct<span style='font-size:1rem;color:#555'>%</span></div>
    <div style='font-size:.75rem;color:#555'>$doneSecs / $totalSecs seções</div>
  </div>
  <div style='background:#111;border:1px solid #1c1c1c;border-radius:10px;padding:1rem;position:relative;overflow:hidden'>
    <div style='position:absolute;top:0;left:0;right:0;height:2px;background:#d97757'></div>
    <div style='font-size:.6rem;letter-spacing:2px;text-transform:uppercase;color:#555;font-family:monospace;margin-bottom:.4rem'>NÍVEL</div>
    <div style='font-size:1.1rem;font-weight:700;margin-top:.2rem'>" . self::level($pct) . "</div>
  </div>
  <div style='background:#111;border:1px solid #1c1c1c;border-radius:10px;padding:1rem;position:relative;overflow:hidden'>
    <div style='position:absolute;top:0;left:0;right:0;height:2px;background:#d97757'></div>
    <div style='font-size:.6rem;letter-spacing:2px;text-transform:uppercase;color:#555;font-family:monospace;margin-bottom:.4rem'>SESSÕES</div>
    <div style='font-size:2rem;font-weight:800'>" . count($hist) . "</div>
  </div>
</div>
<h2 style='font-size:.8rem;font-weight:700;color:#d97757;letter-spacing:2px;text-transform:uppercase;margin-bottom:1rem'>Capítulos</h2>
$capsHtml
<h2 style='font-size:.8rem;font-weight:700;color:#d97757;letter-spacing:2px;text-transform:uppercase;margin:2rem 0 1rem'>Histórico de Sessões</h2>
<div style='background:#111;border:1px solid #1c1c1c;border-radius:10px;overflow:hidden;margin-bottom:2rem'>
  <table style='width:100%;border-collapse:collapse'>
    <thead><tr style='border-bottom:1px solid #1c1c1c'>
      <th style='padding:.5rem .75rem;text-align:left;font-size:.65rem;color:#555;font-family:monospace'>DATA/HORA</th>
      <th style='padding:.5rem .75rem;text-align:left;font-size:.65rem;color:#555;font-family:monospace'>CAP.</th>
      <th style='padding:.5rem .75rem;text-align:left;font-size:.65rem;color:#555;font-family:monospace'>SEÇÃO</th>
    </tr></thead>
    <tbody>$histRows</tbody>
  </table>
</div>
" . ($notesHtml ? "<h2 style='font-size:.8rem;font-weight:700;color:#d97757;letter-spacing:2px;text-transform:uppercase;margin-bottom:1rem'>Minhas Notas</h2>$notesHtml" : '') . "
<div style='border-top:1px solid #1c1c1c;margin-top:2rem;padding-top:1rem;text-align:center;color:#444;font-size:.72rem;font-family:monospace'>
  PHP Expert Platform · Pablo Dall'Oglio 4ª Ed.
</div>
</div></body></html>";

        if (!is_dir(EXPORT_DIR)) mkdir(EXPORT_DIR, 0775, true);
        $filename = 'historico_' . date('Y-m-d_His') . '.html';
        $path = EXPORT_DIR . $filename;
        file_put_contents($path, $html);
        DB::run('INSERT INTO exports (user_id, export_type, filename) VALUES (?,?,?)',
            [$userId, 'html', $filename]);
        return $path;
    }
}
