#!/bin/bash
# ============================================================
#  PHP Expert Platform — Instalador Automático
#  Suporta instalação em SUBPASTA  (ex: http://IP/phpexpert)
#  Compatível com Ubuntu 20.04 / 22.04 / 24.04
#  Apache2 + PHP 8.x + MySQL/MariaDB
# ============================================================
set -e

RED='\033[0;31m'; GRN='\033[0;32m'; YLW='\033[1;33m'
CYN='\033[0;36m'; BLD='\033[1m'; RST='\033[0m'

banner() {
  echo -e "${CYN}"
  echo "  ██████╗ ██╗  ██╗██████╗     ███████╗██╗  ██╗██████╗ ███████╗██████╗ ████████╗"
  echo "  ██╔══██╗██║  ██║██╔══██╗    ██╔════╝╚██╗██╔╝██╔══██╗██╔════╝██╔══██╗╚══██╔══╝"
  echo "  ██████╔╝███████║██████╔╝    █████╗   ╚███╔╝ ██████╔╝█████╗  ██████╔╝   ██║   "
  echo "  ██╔═══╝ ██╔══██║██╔═══╝     ██╔══╝   ██╔██╗ ██╔═══╝ ██╔══╝  ██╔══██╗   ██║   "
  echo "  ██║     ██║  ██║██║         ███████╗██╔╝ ██╗██║     ███████╗██║  ██║   ██║   "
  echo "  ╚═╝     ╚═╝  ╚═╝╚═╝         ╚══════╝╚═╝  ╚═╝╚═╝     ╚══════╝╚═╝  ╚═╝   ╚═╝   "
  echo -e "${RST}"
  echo -e "  ${BLD}Plataforma de Estudos PHP${RST} — Pablo Dall'Oglio"
  echo "  ──────────────────────────────────────────────────────────────"
  echo ""
}

log()  { echo -e "  ${GRN}✓${RST} $1"; }
warn() { echo -e "  ${YLW}!${RST} $1"; }
err()  { echo -e "  ${RED}✗${RST} $1"; exit 1; }
step() { echo -e "\n  ${CYN}▶${RST} ${BLD}$1${RST}"; }

# ── Root check ───────────────────────────────────────────────
[ "$EUID" -ne 0 ] && err "Execute como root: sudo bash install.sh"

banner

# ── Coletar configurações ────────────────────────────────────
echo -e "  ${BLD}Configuração da instalação${RST}"
echo ""

# Modo: subpasta ou domínio próprio?
echo -e "  Modo de instalação:"
echo -e "    ${CYN}1${RST}) Subpasta  — http://IP/phpexpert   ${YLW}(recomendado para VPS compartilhada)${RST}"
echo -e "    ${CYN}2${RST}) Domínio   — http://phpexpert.com  (VirtualHost dedicado)"
echo ""
read -p "  Escolha [1]: " INSTALL_MODE
INSTALL_MODE="${INSTALL_MODE:-1}"

if [ "$INSTALL_MODE" = "1" ]; then
  # ── Modo subpasta ──────────────────────────────────────────
  read -p "  Nome da subpasta [phpexpert]: " INPUT_SUBDIR
  SUBDIR="${INPUT_SUBDIR:-phpexpert}"
  # Remove barra inicial se digitada
  SUBDIR="${SUBDIR#/}"

  # Detectar DocumentRoot do site padrão do Apache
  APACHE_DOCROOT=$(apachectl -S 2>/dev/null | grep "DocumentRoot" | head -1 | awk '{print $2}' | tr -d '"')
  APACHE_DOCROOT="${APACHE_DOCROOT:-/var/www/html}"
  read -p "  DocumentRoot do Apache [$APACHE_DOCROOT]: " INPUT_DOCROOT
  APACHE_DOCROOT="${INPUT_DOCROOT:-$APACHE_DOCROOT}"

  SITE_DIR="$APACHE_DOCROOT/$SUBDIR"
  APP_BASE="/$SUBDIR"
  APP_URL="http://$(hostname -I | awk '{print $1}')/$SUBDIR"
  VHOST_CONF=""  # Não cria VirtualHost — usa o site padrão existente

  echo ""
  log "Instalando em: $SITE_DIR"
  log "URL de acesso: $APP_URL"

else
  # ── Modo domínio/VirtualHost ───────────────────────────────
  read -p "  Domínio/IP do site [phpexpert.local]: " INPUT_DOMAIN
  VHOST_DOMAIN="${INPUT_DOMAIN:-phpexpert.local}"
  SITE_DIR="/var/www/${VHOST_DOMAIN//\./_}"
  APP_BASE=""
  APP_URL="http://$VHOST_DOMAIN"
  SUBDIR=""

  echo ""
  log "VirtualHost: $VHOST_DOMAIN → $SITE_DIR"
fi

echo ""
DB_NAME="phpexpert"
DB_USER="phpexpert"

read -s -p "  Senha para o usuário MySQL 'phpexpert': " DB_PASS
echo ""
if [ -z "$DB_PASS" ]; then
  DB_PASS="phpexpert$(date +%s | sha256sum | head -c 8)"
  warn "Senha gerada: ${BLD}$DB_PASS${RST}  ← anote isso!"
fi

read -p "  Senha root MySQL [Enter = auth socket]: " DB_ROOT_PASS
echo ""

# ── Instalar pacotes ─────────────────────────────────────────
step "Atualizando pacotes"
apt-get update -qq
log "apt update OK"

step "Instalando Apache2, PHP 8.x, MySQL e extensões"
DEBIAN_FRONTEND=noninteractive apt-get install -y -qq \
  apache2 \
  php8.2 php8.2-mysql php8.2-mbstring php8.2-xml php8.2-curl php8.2-zip php8.2-gd \
  mysql-server libapache2-mod-php8.2 unzip curl 2>/dev/null || \
DEBIAN_FRONTEND=noninteractive apt-get install -y -qq \
  apache2 \
  php8.1 php8.1-mysql php8.1-mbstring php8.1-xml php8.1-curl php8.1-zip php8.1-gd \
  mysql-server libapache2-mod-php8.1 unzip curl 2>/dev/null || \
DEBIAN_FRONTEND=noninteractive apt-get install -y -qq \
  apache2 php php-mysql php-mbstring php-xml php-curl php-zip php-gd \
  mysql-server libapache2-mod-php unzip curl
log "Pacotes instalados"

step "Ativando módulos Apache"
a2enmod rewrite headers expires deflate
log "Módulos: rewrite, headers, expires, deflate"

# ── Banco de dados ───────────────────────────────────────────
step "Criando banco de dados MySQL"
if [ -n "$DB_ROOT_PASS" ]; then
  MYSQL_CMD="mysql -u root -p${DB_ROOT_PASS}"
else
  MYSQL_CMD="mysql -u root"
fi

$MYSQL_CMD <<SQLEOF
CREATE DATABASE IF NOT EXISTS \`$DB_NAME\`
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE USER IF NOT EXISTS '$DB_USER'@'localhost' IDENTIFIED BY '$DB_PASS';
GRANT ALL PRIVILEGES ON \`$DB_NAME\`.* TO '$DB_USER'@'localhost';
FLUSH PRIVILEGES;

USE \`$DB_NAME\`;

CREATE TABLE IF NOT EXISTS users (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  username    VARCHAR(80)  NOT NULL UNIQUE,
  password    VARCHAR(255) NOT NULL,
  email       VARCHAR(150),
  created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS progress (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  user_id     INT NOT NULL,
  chapter_id  TINYINT NOT NULL,
  section_idx SMALLINT NOT NULL,
  done        TINYINT(1) DEFAULT 0,
  updated_at  DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_prog (user_id, chapter_id, section_idx),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS notes (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  user_id     INT NOT NULL,
  chapter_id  TINYINT NOT NULL,
  section_idx SMALLINT NOT NULL,
  note_text   TEXT,
  updated_at  DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_note (user_id, chapter_id, section_idx),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS history (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  user_id     INT NOT NULL,
  chapter_id  TINYINT NOT NULL,
  section_idx SMALLINT NOT NULL,
  sec_title   VARCHAR(300),
  viewed_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS exports (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  user_id     INT NOT NULL,
  export_type ENUM('txt','html') NOT NULL,
  filename    VARCHAR(200),
  created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
SQLEOF
log "Banco '$DB_NAME' criado com todas as tabelas"

# ── Copiar arquivos ──────────────────────────────────────────
step "Copiando arquivos do projeto"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
mkdir -p "$SITE_DIR"
mkdir -p "$SITE_DIR/exports"

# Copia tudo exceto a pasta install (não precisa ficar no servidor)
rsync -a --exclude='install/' "$SCRIPT_DIR/" "$SITE_DIR/" 2>/dev/null || \
  cp -r "$SCRIPT_DIR/." "$SITE_DIR/"

log "Arquivos copiados para $SITE_DIR"

# ── Gerar config.php ─────────────────────────────────────────
step "Gerando includes/config.php"
cat > "$SITE_DIR/includes/config.php" <<PHPEOF
<?php
define('DB_HOST',    'localhost');
define('DB_NAME',    '$DB_NAME');
define('DB_USER',    '$DB_USER');
define('DB_PASS',    '$DB_PASS');
define('DB_CHARSET', 'utf8mb4');
define('APP_NAME',   'PHP Expert');
define('APP_VERSION','1.0.0');
define('APP_URL',    '$APP_URL');
define('EXPORT_DIR', __DIR__ . '/../exports/');
define('SESSION_LIFETIME', 86400 * 30);

// Subpasta onde a plataforma está instalada.
// '' = raiz  |  '/phpexpert' = subpasta
define('APP_BASE', '$APP_BASE');

function url(string \$path = '/'): string {
    \$base = rtrim(APP_BASE, '/');
    if (\$path === '/') return \$base . '/';
    return \$base . '/' . ltrim(\$path, '/');
}
PHPEOF
log "Config gerada com APP_BASE='$APP_BASE'"

# ── Gerar .htaccess correto ──────────────────────────────────
step "Gerando .htaccess"
if [ -n "$APP_BASE" ]; then
  REWRITE_BASE="${APP_BASE}/"
else
  REWRITE_BASE="/"
fi

cat > "$SITE_DIR/public/.htaccess" <<HTEOF
Options -Indexes
RewriteEngine On
RewriteBase $REWRITE_BASE

RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^(.*)$ index.php [QSA,L]

<IfModule mod_headers.c>
    Header always set X-Content-Type-Options  "nosniff"
    Header always set X-Frame-Options         "SAMEORIGIN"
    Header always set X-XSS-Protection        "1; mode=block"
    Header always set Referrer-Policy         "same-origin"
</IfModule>

<FilesMatch "\.(sql|log|env|sh|json|lock|md)$">
    Require all denied
</FilesMatch>

<IfModule mod_expires.c>
    ExpiresActive On
    ExpiresByType text/css               "access plus 1 month"
    ExpiresByType application/javascript "access plus 1 month"
</IfModule>

<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/html text/css application/javascript text/plain
</IfModule>
HTEOF
log ".htaccess gerado com RewriteBase=$REWRITE_BASE"

# ── VirtualHost (apenas modo domínio) ────────────────────────
if [ "$INSTALL_MODE" = "2" ]; then
  step "Criando VirtualHost Apache"
  CONF_NAME="${VHOST_DOMAIN//\./_}"
  cat > "/etc/apache2/sites-available/${CONF_NAME}.conf" <<APACHEEOF
<VirtualHost *:80>
    ServerName $VHOST_DOMAIN
    DocumentRoot $SITE_DIR/public
    DirectoryIndex index.php

    <Directory $SITE_DIR/public>
        Options +FollowSymLinks -Indexes
        AllowOverride All
        Require all granted
    </Directory>

    # Proteger pastas internas
    <Directory $SITE_DIR/includes>
        Require all denied
    </Directory>
    <Directory $SITE_DIR/data>
        Require all denied
    </Directory>

    Header always set X-Content-Type-Options nosniff
    Header always set X-Frame-Options SAMEORIGIN

    <IfModule mod_deflate.c>
        AddOutputFilterByType DEFLATE text/html text/css application/javascript text/plain
    </IfModule>

    ErrorLog  \${APACHE_LOG_DIR}/${CONF_NAME}_error.log
    CustomLog \${APACHE_LOG_DIR}/${CONF_NAME}_access.log combined
</VirtualHost>
APACHEEOF
  a2ensite "${CONF_NAME}.conf"
  log "VirtualHost criado: $VHOST_DOMAIN"

  # /etc/hosts para .local
  if [[ "$VHOST_DOMAIN" == *".local"* ]]; then
    grep -q "$VHOST_DOMAIN" /etc/hosts || \
      echo "127.0.0.1  $VHOST_DOMAIN" >> /etc/hosts
    log "/etc/hosts atualizado"
  fi

else
  # ── Modo subpasta ────────────────────────────────────────────
  step "Configurando Apache para subpasta /$SUBDIR"

  MAIN_CONF="/etc/apache2/apache2.conf"
  sed -i '/^<Directory \/var\/www\/>/,/^<\/Directory>/ s/AllowOverride None/AllowOverride All/' "$MAIN_CONF"
  log "apache2.conf: AllowOverride All no bloco /var/www/"

  DEFAULT_CONF="/etc/apache2/sites-enabled/000-default.conf"
  [ -f "$DEFAULT_CONF" ] && sed -i 's/AllowOverride None/AllowOverride All/g' "$DEFAULT_CONF" && log "000-default.conf: AllowOverride All"

  ALIAS_CONF="/etc/apache2/conf-available/${SUBDIR}_alias.conf"
  cat > "$ALIAS_CONF" <<ALIASEOF
# PHP Expert — Alias /$SUBDIR
Alias /$SUBDIR "$SITE_DIR/public"

<Directory "$SITE_DIR/public">
    Options +FollowSymLinks -Indexes
    AllowOverride All
    Require all granted
</Directory>

<Directory "$SITE_DIR/includes">
    Require all denied
</Directory>

<Directory "$SITE_DIR/data">
    Require all denied
</Directory>
ALIASEOF
  a2enconf "${SUBDIR}_alias"
  log "Alias /$SUBDIR -> $SITE_DIR/public com Require all granted"

  a2enmod rewrite headers expires deflate 2>/dev/null
  log "Módulos Apache ativados"
fi

# ── Permissões ───────────────────────────────────────────────
step "Configurando permissões"
chown -R www-data:www-data "$SITE_DIR"
chmod -R 755 "$SITE_DIR"
chmod -R 775 "$SITE_DIR/exports"
log "Permissões OK"

# ── Reload Apache ────────────────────────────────────────────
step "Recarregando Apache"
systemctl reload apache2
log "Apache recarregado"

# ── Resumo final ─────────────────────────────────────────────
echo ""
echo -e "  ╔══════════════════════════════════════════════════════╗"
echo -e "  ║  ${GRN}${BLD}INSTALAÇÃO CONCLUÍDA!${RST}"
echo -e "  ╠══════════════════════════════════════════════════════╣"
echo -e "  ║  ${BLD}URL:${RST}     ${CYN}$APP_URL${RST}"
echo -e "  ║  ${BLD}Pasta:${RST}   $SITE_DIR"
echo -e "  ║  ${BLD}Banco:${RST}   $DB_NAME @ localhost"
echo -e "  ║  ${BLD}Usuário:${RST} $DB_USER"
echo -e "  ║  ${BLD}Senha:${RST}   ${YLW}$DB_PASS${RST}"
echo -e "  ╠══════════════════════════════════════════════════════╣"
echo -e "  ║  ${YLW}Crie sua conta no primeiro acesso!${RST}"
if [ "$INSTALL_MODE" = "1" ]; then
echo -e "  ║  ${YLW}Outras plataformas podem usar o mesmo Apache.${RST}"
fi
echo -e "  ╚══════════════════════════════════════════════════════╝"
echo ""
