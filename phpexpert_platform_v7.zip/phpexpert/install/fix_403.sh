#!/bin/bash
# ============================================================
#  PHP Expert — Correção rápida de erro 403 Forbidden
#  Execute na VPS: sudo bash fix_403.sh
# ============================================================
set -e
RED='\033[0;31m'; GRN='\033[0;32m'; YLW='\033[1;33m'
CYN='\033[0;36m'; BLD='\033[1m'; RST='\033[0m'

log()  { echo -e "  ${GRN}✓${RST} $1"; }
warn() { echo -e "  ${YLW}!${RST} $1"; }
err()  { echo -e "  ${RED}✗${RST} $1"; }
step() { echo -e "\n  ${CYN}▶${RST} ${BLD}$1${RST}"; }

[ "$EUID" -ne 0 ] && echo "Execute como root: sudo bash fix_403.sh" && exit 1

echo -e "\n  ${CYN}${BLD}PHP Expert — Correção de 403 Forbidden${RST}\n"

# Detectar onde está instalado
read -p "  Subpasta usada na instalação [phpexpert]: " SUBDIR
SUBDIR="${SUBDIR:-phpexpert}"

read -p "  DocumentRoot do Apache [/var/www/html]: " DOCROOT
DOCROOT="${DOCROOT:-/var/www/html}"

SITE_DIR="$DOCROOT/$SUBDIR"
ALIAS_CONF="/etc/apache2/conf-available/${SUBDIR}_alias.conf"

echo ""
log "Detectando configuração..."

# ── 1. Verificar se a pasta existe ───────────────────────────
step "Verificando diretório"
if [ -d "$SITE_DIR/public" ]; then
    log "Pasta encontrada: $SITE_DIR/public"
else
    err "Pasta NÃO encontrada: $SITE_DIR/public"
    echo "  Verifique se o ZIP foi extraído corretamente."
    exit 1
fi

# ── 2. Corrigir permissões ────────────────────────────────────
step "Corrigindo permissões"
chown -R www-data:www-data "$SITE_DIR"
chmod -R 755 "$SITE_DIR"
chmod -R 775 "$SITE_DIR/exports" 2>/dev/null || mkdir -p "$SITE_DIR/exports" && chmod 775 "$SITE_DIR/exports"
log "Permissões: www-data:www-data 755"

# ── 3. Habilitar módulos Apache essenciais ────────────────────
step "Habilitando módulos Apache"
a2enmod rewrite headers expires deflate 2>/dev/null
log "Módulos: rewrite, headers, expires, deflate"

# ── 4. Reescrever alias conf com Require all granted explícito ─
step "Recriando configuração do Alias Apache"
cat > "$ALIAS_CONF" << ALIASEOF
# PHP Expert — Alias subpasta /$SUBDIR
Alias /$SUBDIR "$SITE_DIR/public"

<Directory "$SITE_DIR/public">
    Options +FollowSymLinks -Indexes
    AllowOverride All
    Require all granted
</Directory>

# Proteger pastas internas (fora do public)
<Directory "$SITE_DIR/includes">
    Require all denied
</Directory>

<Directory "$SITE_DIR/data">
    Require all denied
</Directory>
ALIASEOF
a2enconf "${SUBDIR}_alias" 2>/dev/null || true
log "Alias /$SUBDIR → $SITE_DIR/public"

# ── 5. Corrigir AllowOverride em apache2.conf ────────────────
step "Corrigindo AllowOverride em apache2.conf"
MAIN_CONF="/etc/apache2/apache2.conf"

# Apache 2.4 Ubuntu: <Directory /var/www/> pode ter AllowOverride None
if grep -q "AllowOverride None" "$MAIN_CONF"; then
    # Só substituir dentro do bloco /var/www/
    sed -i '/^<Directory \/var\/www\/>/,/^<\/Directory>/ s/AllowOverride None/AllowOverride All/' "$MAIN_CONF"
    log "AllowOverride corrigido em apache2.conf"
else
    log "AllowOverride já estava OK em apache2.conf"
fi

# ── 6. Corrigir 000-default.conf se necessário ───────────────
step "Verificando site padrão (000-default.conf)"
DEFAULT_CONF="/etc/apache2/sites-enabled/000-default.conf"
if [ -f "$DEFAULT_CONF" ]; then
    if grep -q "AllowOverride None" "$DEFAULT_CONF"; then
        sed -i 's/AllowOverride None/AllowOverride All/g' "$DEFAULT_CONF"
        log "AllowOverride corrigido em 000-default.conf"
    else
        log "000-default.conf OK"
    fi
fi

# ── 7. Reescrever .htaccess correto ──────────────────────────
step "Reescrevendo .htaccess"
cat > "$SITE_DIR/public/.htaccess" << HTEOF
Options +FollowSymLinks -Indexes
RewriteEngine On
RewriteBase /$SUBDIR/

# Não reescrever arquivos/pastas reais
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^(.*)$ index.php [QSA,L]

<IfModule mod_headers.c>
    Header always set X-Content-Type-Options "nosniff"
    Header always set X-Frame-Options "SAMEORIGIN"
</IfModule>

<FilesMatch "\.(sql|log|env|sh|lock)$">
    Require all denied
</FilesMatch>

<IfModule mod_expires.c>
    ExpiresActive On
    ExpiresByType text/css               "access plus 1 month"
    ExpiresByType application/javascript "access plus 1 month"
</IfModule>

<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/html text/css application/javascript text/plain
</IfModule>
HTEOF
log ".htaccess reescrito com RewriteBase=/$SUBDIR/"

# ── 8. Teste de configuração Apache ──────────────────────────
step "Testando configuração Apache"
if apache2ctl configtest 2>&1 | grep -q "Syntax OK"; then
    log "Configuração Apache: Syntax OK"
else
    err "Erro na configuração Apache:"
    apache2ctl configtest
fi

# ── 9. Reload Apache ─────────────────────────────────────────
step "Recarregando Apache"
systemctl reload apache2
log "Apache recarregado"

# ── Resumo ───────────────────────────────────────────────────
IP=$(hostname -I | awk '{print $1}')
echo ""
echo -e "  ╔══════════════════════════════════════════════════════╗"
echo -e "  ║  ${GRN}${BLD}Correção aplicada!${RST}"
echo -e "  ║"
echo -e "  ║  Acesse agora: ${CYN}http://$IP/$SUBDIR/${RST}"
echo -e "  ║"
echo -e "  ║  Se ainda der erro, acesse o diagnóstico:"
echo -e "  ║  ${CYN}http://$IP/$SUBDIR/debug.php${RST}"
echo -e "  ╚══════════════════════════════════════════════════════╝"
echo ""
