# PHP Expert — Plataforma de Estudos

Plataforma completa de estudos baseada no livro **"PHP Programando com Orientação a Objetos"** — Pablo Dall'Oglio, 4ª Edição.

---

## Stack utilizada

| Camada      | Tecnologia              |
|-------------|-------------------------|
| Backend     | PHP 7.4+ / 8.x          |
| Banco       | MySQL 8 / MariaDB 10.6+ |
| Servidor    | Apache2 + mod_rewrite   |
| Frontend    | HTML5 + CSS3 + JS puro  |
| Fontes      | JetBrains Mono + Geist  |

---

## Instalação em VPS / Servidor local (Ubuntu)

### 1. Enviar os arquivos

```bash
# Opção A — SCP
scp -r ./phpexpert usuario@seu-servidor:/tmp/

# Opção B — clonar de um repositório
git clone https://github.com/seu-usuario/phpexpert /tmp/phpexpert
```

### 2. Executar o instalador

```bash
cd /tmp/phpexpert
sudo bash install/install.sh
```

O script faz automaticamente:
- Instala Apache2, PHP, MySQL e extensões necessárias
- Cria o banco de dados com todas as tabelas
- Cria o usuário MySQL com as permissões corretas
- Copia os arquivos para `/var/www/phpexpert`
- Configura o VirtualHost Apache
- Ajusta permissões de pastas
- Adiciona entrada no `/etc/hosts` para domínio `.local`

### 3. Acessar

Abra no navegador:
```
http://phpexpert.local
```
Ou o domínio/IP que você configurou durante a instalação.

---

## Instalação manual (sem o script)

### 1. Dependências
```bash
sudo apt update
sudo apt install -y apache2 php8.1 php8.1-mysql php8.1-mbstring \
     php8.1-xml php8.1-curl php8.1-zip libapache2-mod-php8.1 mysql-server
sudo a2enmod rewrite headers expires deflate
```

### 2. Banco de dados
```bash
sudo mysql -u root
```
```sql
CREATE DATABASE phpexpert CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'phpexpert'@'localhost' IDENTIFIED BY 'SUA_SENHA';
GRANT ALL PRIVILEGES ON phpexpert.* TO 'phpexpert'@'localhost';
FLUSH PRIVILEGES;
```

Execute o arquivo `install/schema.sql` para criar as tabelas:
```bash
sudo mysql -u phpexpert -p phpexpert < install/schema.sql
```

### 3. Configuração
Edite `includes/config.php`:
```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'phpexpert');
define('DB_USER', 'phpexpert');
define('DB_PASS', 'SUA_SENHA');
define('APP_URL', 'http://phpexpert.local');
define('EXPORT_DIR', __DIR__ . '/../exports/');
```

### 4. Apache VirtualHost
```apache
<VirtualHost *:80>
    ServerName phpexpert.local
    DocumentRoot /var/www/phpexpert/public
    DirectoryIndex index.php

    <Directory /var/www/phpexpert/public>
        AllowOverride All
        Require all granted
    </Directory>
</VirtualHost>
```
```bash
sudo a2ensite phpexpert
sudo systemctl reload apache2
```

---

## Estrutura de pastas

```
phpexpert/
├── public/             # DocumentRoot Apache — acessível via web
│   ├── index.php       # Trilha principal de estudos
│   ├── login.php       # Login e registro
│   ├── history.php     # Histórico de sessões
│   ├── export.php      # Gerar e baixar relatórios
│   ├── api.php         # API JSON (AJAX)
│   ├── .htaccess       # Regras Apache
│   └── assets/         # CSS, JS, imagens
├── includes/
│   ├── config.php      # Configurações (DB, URLs)
│   ├── db.php          # PDO + classes Auth, Progress, Notes, History, Exporter
│   └── layout.php      # Header/footer compartilhados
├── data/
│   └── book_data.php   # Conteúdo completo do livro (468 seções)
├── exports/            # Arquivos gerados (TXT/HTML) — precisa de permissão 775
└── install/
    ├── install.sh      # Instalador automático
    └── schema.sql      # SQL das tabelas (para instalação manual)
```

---

## Funcionalidades

- **Trilha de estudos** com 8 capítulos e 468 seções do livro
- **Conteúdo completo** de cada seção com texto explicativo e código PHP
- **Progresso por seção** salvo no MySQL por usuário
- **Sistema de notas** por seção (salvo automaticamente via AJAX)
- **Histórico automático** de todas as seções acessadas com timestamp
- **Exportação .TXT** — relatório em texto puro com progresso, histórico e notas
- **Exportação .HTML** — relatório visual formatado (design Claude Code) para abrir offline
- **Multi-usuário** — cada pessoa tem login próprio com progresso independente
- **Design Claude Code** — JetBrains Mono + Geist, dark theme, laranja #d97757

---

## Segurança

- Senhas em bcrypt via `password_hash()`
- PDO com prepared statements (sem SQL injection)
- Arquivos `includes/` e `data/` protegidos pelo Apache (acesso negado via web)
- Headers de segurança configurados no VirtualHost e .htaccess
- Sessões com `httponly` e `samesite=Lax`

---

## Suporte

Baseado em: **PHP Programando com Orientação a Objetos** — Pablo Dall'Oglio, 4ª Edição (Novatec)
