/* assets/js/app.js */
'use strict';

// ── PHP Syntax Highlighter ───────────────────────────────────
function hlPHP(raw) {
  const esc = raw
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  return esc
    .replace(/(\/\/[^\n]*)|(#[^\n]*)/g, '<span class="cmt">$1$2</span>')
    .replace(/('(?:[^'\\]|\\.)*'|"(?:[^"\\]|\\.)*")/g, '<span class="str">$1</span>')
    .replace(/\b(class|extends|implements|interface|abstract|final|trait|namespace|use|function|return|new|echo|print|var_dump|print_r|if|else|elseif|foreach|for|while|do|switch|case|break|continue|try|catch|throw|require|include|require_once|include_once|public|private|protected|static|const|null|true|false|void|self|parent|match|fn)\b/g,
      '<span class="kw">$1</span>')
    .replace(/\b(int|string|float|bool|array|object|callable|iterable|mixed)\b/g,
      '<span class="type">$1</span>')
    .replace(/(\$[a-zA-Z_][a-zA-Z0-9_]*)/g, '<span class="var">$1</span>')
    .replace(/\b([a-zA-Z_][a-zA-Z0-9_]*)\s*(?=\()/g, '<span class="fn">$1</span>')
    .replace(/\b(-?\d+\.?\d*)\b/g, '<span class="num">$1</span>');
}

function makeCodeBlock(code, label='PHP') {
  const id = 'cb' + Math.random().toString(36).slice(2,8);
  return `<div class="code-block">
    <div class="code-header">
      <div class="code-dots"><span></span><span></span><span></span></div>
      <span class="code-lang">${label}</span>
      <button class="copy-btn" onclick="copyCode('${id}',this)">copiar</button>
    </div>
    <pre id="${id}">${hlPHP(code)}</pre>
  </div>`;
}

function copyCode(id, btn) {
  const text = document.getElementById(id)?.innerText || '';
  navigator.clipboard.writeText(text).then(() => {
    btn.textContent = 'copiado!';
    btn.classList.add('copied');
    setTimeout(() => { btn.textContent = 'copiar'; btn.classList.remove('copied'); }, 2000);
  });
}

// ── Progress bar update ──────────────────────────────────────
function updateTopbarProgress(done, total) {
  const pct = total > 0 ? Math.round(done/total*100) : 0;
  const fill = document.getElementById('tbProgFill');
  const pctEl = document.getElementById('tbPct');
  if (fill)  fill.style.width = pct + '%';
  if (pctEl) pctEl.textContent = pct + '%';
}

// ── AJAX fetch helper ────────────────────────────────────────
async function api(endpoint, data={}) {
  const res = await fetch('/api.php', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({action: endpoint, ...data})
  });
  return res.json();
}

// ── Section reader ───────────────────────────────────────────
let currentSec = null;
let currentTab = 'content';

// Safe entry point: looks up data from BOOK_MAP (never inline onclick)
function openSectionByIndex(chapId, secIdx) {
  const cap = (typeof BOOK_MAP !== 'undefined') ? BOOK_MAP[chapId] : null;
  if (!cap || !cap[secIdx]) {
    console.error('BOOK_MAP missing cap', chapId, 'sec', secIdx);
    return;
  }
  const sec = cap[secIdx];
  openSection(chapId, secIdx, sec.title, sec.content);
}

function openSection(chapId, secIdx, title, content) {
  currentSec = {chapId, secIdx, title, content};
  document.getElementById('rTitle').textContent = title;
  document.getElementById('rCapLabel').textContent = `Capítulo ${chapId}`;

  const reader = document.getElementById('reader');
  reader.classList.add('open');
  switchTab('content');

  // Record history
  api('history', {cap: chapId, sec: secIdx, title});
  reader.scrollIntoView({behavior:'smooth', block:'nearest'});

  // Highlight current in sidebar
  document.querySelectorAll('.sec-row').forEach(r => r.classList.remove('sec-active'));
  const row = document.querySelector(`[data-cap="${chapId}"][data-sec="${secIdx}"]`);
  if (row) row.classList.add('sec-active');
}

function switchTab(tab, el=null) {
  if (!currentSec) return;
  currentTab = tab;
  document.querySelectorAll('.r-tab').forEach(t => t.classList.remove('on'));
  if (el) el.classList.add('on');
  else {
    const tEl = document.querySelector(`.r-tab[data-tab="${tab}"]`);
    if (tEl) tEl.classList.add('on');
  }
  renderReaderTab();
}

function renderReaderTab() {
  if (!currentSec) return;
  const {chapId, secIdx, content} = currentSec;
  const body = document.getElementById('rBody');

  if (currentTab === 'content') {
    // Split into prose + code blocks
    const parts = content.split(/((?:<\?php|<\?PHP)[\s\S]*?)(?=\n\n(?!\s*\$|\s*\/\/)|$)/g);
    let html = '<div class="prose">';
    parts.forEach(part => {
      const trimmed = part.trim();
      if (!trimmed) return;
      if (trimmed.startsWith('<?php') || trimmed.startsWith('<?PHP')) {
        html += makeCodeBlock(trimmed);
      } else {
        trimmed.split(/\n\n+/).forEach(para => {
          if (para.trim()) {
            // Detect bullet lists
            if (para.trim().startsWith('•') || para.trim().startsWith('-')) {
              const items = para.split(/\n/).filter(l=>l.trim());
              html += '<ul>' + items.map(l=>`<li>${escHtml(l.replace(/^[•\-]\s*/,''))}</li>`).join('') + '</ul>';
            } else {
              html += `<p>${escHtml(para.trim()).replace(/\n/g,'<br>')}</p>`;
            }
          }
        });
      }
    });
    html += '</div>';
    html += `<div class="btn-row">
      <button class="btn btn-sm" onclick="markDone(${chapId},${secIdx},false)">✗ Desmarcar</button>
      <button class="btn btn-success btn-sm" onclick="markDone(${chapId},${secIdx},true)">✓ Concluído</button>
    </div>`;
    body.innerHTML = html;

  } else if (currentTab === 'code') {
    const codes = content.match(/(<\?php|<\?PHP)[\s\S]*?(?=\n\n(?!\s*[\$\/])|$)/g) || [];
    if (codes.length === 0) {
      body.innerHTML = `<div class="callout callout-info"><span class="callout-icon">ℹ️</span>
        <div>Esta seção não possui exemplos de código isolados. Veja a aba Conteúdo para o texto completo.</div></div>`;
    } else {
      body.innerHTML = codes.map((c,i) => makeCodeBlock(c.trim(), `Exemplo ${i+1}`)).join('');
    }

  } else if (currentTab === 'notes') {
    api('get_note', {cap: chapId, sec: secIdx}).then(r => {
      body.innerHTML = `
        <p class="text-muted text-mono" style="font-size:.72rem;margin-bottom:8px">Notas — ${escHtml(currentSec.title)}</p>
        <textarea class="notes-ta" id="noteTa" placeholder="Escreva resumos, dúvidas, insights...">${escHtml(r.note||'')}</textarea>
        <div class="callout callout-success mt-1">
          <span class="callout-icon">💡</span>
          <div>Escrever com suas próprias palavras acelera o aprendizado. Salvo automaticamente.</div>
        </div>`;
      document.getElementById('noteTa')?.addEventListener('input', debounce(e => {
        api('save_note', {cap: chapId, sec: secIdx, text: e.target.value});
      }, 600));
    });
  }
}

function closeReader() {
  document.getElementById('reader').classList.remove('open');
  currentSec = null;
  document.querySelectorAll('.sec-row').forEach(r => r.classList.remove('sec-active'));
}

// ── Toggle done ──────────────────────────────────────────────
function markDone(cap, sec, done) {
  api('toggle', {cap, sec, done}).then(r => {
    // Update sidebar dot
    const row = document.querySelector(`[data-cap="${cap}"][data-sec="${sec}"]`);
    if (row) { row.classList.toggle('sec-done', done); }
    // Update card
    refreshCapCard(cap);
    updateTopbarProgress(r.total_done, r.total_secs);
  });
}

function toggleTopicCheck(cap, idx) {
  const item = document.querySelector(`[data-chk-cap="${cap}"][data-chk-idx="${idx}"]`);
  const done = !item.classList.contains('done');
  item.classList.toggle('done', done);
  const box = item.querySelector('.chk-box');
  if (box) box.textContent = done ? '✓' : '';
  api('toggle_topic', {cap, idx, done}).then(r => {
    updateTopbarProgress(r.total_done, r.total_secs);
    refreshCapCard(cap);
  });
}

function refreshCapCard(cap) {
  api('cap_progress', {cap}).then(r => {
    const card = document.querySelector(`[data-card-cap="${cap}"]`);
    if (!card) return;
    const fill = card.querySelector('.cc-fill');
    const pct  = card.querySelector('.cc-pct');
    const badge = card.querySelector('.cc-badge');
    if (fill)  fill.style.width = r.pct + '%';
    if (pct)   pct.textContent = `${r.done}/${r.total}`;
    if (badge) {
      badge.className = 'cc-badge ' + (r.pct===100?'b-done':r.done>0?'b-wip':'b-todo');
      badge.textContent = r.pct===100?'Concluído':r.done>0?'Em andamento':'Pendente';
    }
    if (r.pct === 100) card.classList.add('card-done');
    else card.classList.remove('card-done');

    // Sidebar cap num
    const capNum = document.querySelector(`[data-capnum="${cap}"]`);
    if (capNum) capNum.textContent = r.pct===100 ? '✓' : cap;
    const capEl = document.querySelector(`[data-capbtn="${cap}"]`);
    if (capEl) capEl.classList.toggle('cap-done', r.pct===100);
  });
}

// ── Sidebar toggles ──────────────────────────────────────────
function toggleCap(id) {
  const list = document.getElementById('sl-'+id);
  const btn  = document.querySelector(`[data-capbtn="${id}"]`);
  if (!list || !btn) return;
  const isOpen = list.classList.toggle('open');
  btn.classList.toggle('cap-open', isOpen);
}

// ── Search filter ────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  const srch = document.getElementById('sbSearch');
  if (srch) {
    srch.addEventListener('input', () => {
      const q = srch.value.toLowerCase().trim();
      document.querySelectorAll('.cap-group').forEach(grp => {
        const rows = grp.querySelectorAll('.sec-row');
        let anyMatch = false;
        rows.forEach(row => {
          const text = row.dataset.title?.toLowerCase() || row.textContent.toLowerCase();
          const match = !q || text.includes(q);
          row.style.display = match ? '' : 'none';
          if (match) anyMatch = true;
        });
        // Open group if search results
        if (q && anyMatch) {
          const list = grp.querySelector('.sec-list');
          const btn = grp.querySelector('.cap-btn');
          if (list) list.classList.add('open');
          if (btn)  btn.classList.add('cap-open');
        }
        grp.style.display = (!q || anyMatch) ? '' : 'none';
      });
    });
  }

  // Auto-save last read section on page load
  const lastSec = sessionStorage.getItem('lastSec');
  // (restore is handled by PHP on page load via history table)
});

// ── Utilities ────────────────────────────────────────────────
function escHtml(s) {
  return String(s)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;');
}

function debounce(fn, ms) {
  let t;
  return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
}

// ── Flash auto-dismiss ───────────────────────────────────────
document.querySelectorAll('.flash').forEach(el => {
  setTimeout(() => el.style.opacity = '0', 3000);
  setTimeout(() => el.remove(), 3500);
});
