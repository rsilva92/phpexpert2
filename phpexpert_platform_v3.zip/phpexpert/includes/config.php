<?php
// includes/config.php  — gerado pelo instalador
// Este arquivo é sobrescrito pelo install.sh com os dados reais
define('DB_HOST',    'localhost');
define('DB_NAME',    'phpexpert');
define('DB_USER',    'phpexpert');
define('DB_PASS',    'changeme');
define('DB_CHARSET', 'utf8mb4');
define('APP_NAME',   'PHP Expert');
define('APP_VERSION','1.0.0');
define('APP_URL',    'http://localhost');
define('EXPORT_DIR', __DIR__ . '/../exports/');
define('SESSION_LIFETIME', 86400 * 30);

// Subpasta onde a plataforma está instalada.
// Exemplos:
//   ''          → http://IP/           (raiz)
//   '/phpexpert' → http://IP/phpexpert/
//   '/estudos'   → http://IP/estudos/
define('APP_BASE', '/phpexpert');

/**
 * Gera URL correta independente de subpasta.
 * url('/login.php')  →  /phpexpert/login.php
 * url('/')           →  /phpexpert/
 */
function url(string $path = '/'): string {
    $base = rtrim(APP_BASE, '/');
    if ($path === '/') return $base . '/';
    return $base . '/' . ltrim($path, '/');
}
