<?php
// public/export_download.php — secure file download
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';
Auth::start(); Auth::require();

$uid      = Auth::id();
$filename = basename($_GET['file'] ?? '');
if (!$filename) { header('Location: ' . url('/export.php')); exit; }

// Verify this export belongs to this user
$exp = DB::one(
    'SELECT * FROM exports WHERE user_id=? AND filename=?',
    [$uid, $filename]
);
if (!$exp) { http_response_code(403); echo 'Acesso negado.'; exit; }

$path = EXPORT_DIR . $filename;
if (!file_exists($path)) { http_response_code(404); echo 'Arquivo não encontrado.'; exit; }

$mime = str_ends_with($filename, '.html') ? 'text/html' : 'text/plain';
header("Content-Type: $mime; charset=utf-8");
header("Content-Disposition: attachment; filename=\"$filename\"");
header('Content-Length: ' . filesize($path));
readfile($path);
