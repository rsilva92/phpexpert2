<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/layout.php';

Auth::start(); Auth::require();
$uid  = Auth::id();
$hist = History::recent($uid, 200);

page_start('Histórico de Estudos');
?>
<aside class="sidebar" style="display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;padding:24px">
  <div style="font-size:3rem">🕐</div>
  <p style="color:var(--t3);font-size:.8rem;text-align:center;max-width:180px;line-height:1.5">
    Todas as seções que você acessou ficam registradas aqui.
  </p>
  <a href="<?= url('/') ?>" class="btn btn-primary btn-sm" style="margin-top:8px">← Voltar à Trilha</a>
</aside>

<main class="main">
  <div class="hero">
    <div class="hero-eyebrow">Sessões registradas automaticamente</div>
    <h1>Histórico de Estudos</h1>
    <p class="hero-sub">Cada seção que você abrir é salva aqui com data e hora. Use para retomar de onde parou.</p>
    <div class="hero-tags">
      <span class="tag tag-muted"><?= count($hist) ?> sessões</span>
      <span class="tag tag-ora">Salvo automaticamente</span>
    </div>
  </div>

  <div class="content">

    <?php if (!empty($hist)): ?>
    <div class="section-header">
      <h2>Últimas sessões</h2>
    </div>
    <table class="hist-table" style="margin-bottom:24px">
      <thead>
        <tr>
          <th>DATA / HORA</th>
          <th>CAP.</th>
          <th>SEÇÃO ESTUDADA</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($hist as $h): ?>
        <tr>
          <td class="hist-ts"><?= htmlspecialchars($h['viewed_at']) ?></td>
          <td class="hist-cap">Cap. <?= $h['chapter_id'] ?></td>
          <td class="hist-sec"><?= htmlspecialchars($h['sec_title']) ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>

    <div style="display:flex;gap:10px;flex-wrap:wrap">
      <a href="<?= url('/export.php?type=html') ?>" class="btn btn-primary">🌐 Exportar como HTML</a>
      <a href="<?= url('/export.php?type=txt') ?>"  class="btn">📄 Exportar como TXT</a>
    </div>

    <?php else: ?>
    <div class="callout callout-info">
      <span class="callout-icon">ℹ️</span>
      <div>Nenhuma sessão registrada ainda. Acesse qualquer seção na trilha principal para começar a registrar seu histórico.</div>
    </div>
    <a href="<?= url('/') ?>" class="btn btn-primary mt-2">→ Ir para a Trilha</a>
    <?php endif; ?>

  </div>
</main>

<?php page_end(); ?>
