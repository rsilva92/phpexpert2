<?php
// public/api.php — JSON API para chamadas AJAX
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';

header('Content-Type: application/json');
Auth::start();

$uid = Auth::id();
if (!$uid) { http_response_code(401); echo json_encode(['error'=>'not_authenticated']); exit; }

$body   = json_decode(file_get_contents('php://input'), true) ?? [];
$action = $body['action'] ?? '';

$bookData = require __DIR__ . '/../data/book_data.php';

// Total sections helper
$totalSecs = 0;
foreach ($bookData as $cap) $totalSecs += count($cap['sections']);

function totalDone(int $uid): int {
    $r = DB::one('SELECT COUNT(*) as c FROM progress WHERE user_id=? AND done=1', [$uid]);
    return (int)($r['c'] ?? 0);
}

switch ($action) {

    // Toggle a section done/undone
    case 'toggle':
        $cap  = (int)($body['cap'] ?? 0);
        $sec  = (int)($body['sec'] ?? 0);
        $done = (bool)($body['done'] ?? false);
        Progress::toggle($uid, $cap, $sec, $done);
        echo json_encode([
            'ok'         => true,
            'total_done' => totalDone($uid),
            'total_secs' => $totalSecs,
        ]);
        break;

    // Toggle a checklist topic (chapter-level)
    case 'toggle_topic':
        $cap  = (int)($body['cap'] ?? 0);
        $idx  = (int)($body['idx'] ?? 0);
        $done = (bool)($body['done'] ?? false);
        DB::run(
            'INSERT INTO progress (user_id, chapter_id, section_idx, done)
             VALUES (?,?,?,?)
             ON DUPLICATE KEY UPDATE done=?, updated_at=NOW()',
            [$uid, $cap, 10000+$idx, $done, $done]  // 10000+ offset = topic items
        );
        echo json_encode([
            'ok'         => true,
            'total_done' => totalDone($uid),
            'total_secs' => $totalSecs,
        ]);
        break;

    // Get progress for one chapter (for card refresh)
    case 'cap_progress':
        $cap = (int)($body['cap'] ?? 0);
        $capSecs = count($bookData[$cap]['sections'] ?? []);
        $done = DB::one(
            'SELECT COUNT(*) as c FROM progress WHERE user_id=? AND chapter_id=? AND done=1 AND section_idx < 10000',
            [$uid, $cap]
        );
        $d = (int)($done['c'] ?? 0);
        $pct = $capSecs > 0 ? round($d / $capSecs * 100) : 0;
        echo json_encode(['done'=>$d, 'total'=>$capSecs, 'pct'=>$pct]);
        break;

    // Record history entry
    case 'history':
        $cap   = (int)($body['cap'] ?? 0);
        $sec   = (int)($body['sec'] ?? 0);
        $title = substr($body['title'] ?? '', 0, 300);
        History::record($uid, $cap, $sec, $title);
        echo json_encode(['ok' => true]);
        break;

    // Get note for a section
    case 'get_note':
        $cap = (int)($body['cap'] ?? 0);
        $sec = (int)($body['sec'] ?? 0);
        echo json_encode(['note' => Notes::getOne($uid, $cap, $sec)]);
        break;

    // Save note
    case 'save_note':
        $cap  = (int)($body['cap'] ?? 0);
        $sec  = (int)($body['sec'] ?? 0);
        $text = substr($body['text'] ?? '', 0, 10000);
        Notes::save($uid, $cap, $sec, $text);
        echo json_encode(['ok' => true]);
        break;

    // Get overall stats
    case 'stats':
        $done = totalDone($uid);
        $pct  = $totalSecs > 0 ? round($done / $totalSecs * 100) : 0;
        echo json_encode([
            'done'  => $done,
            'total' => $totalSecs,
            'pct'   => $pct,
        ]);
        break;

    default:
        http_response_code(400);
        echo json_encode(['error' => 'unknown_action']);
}
