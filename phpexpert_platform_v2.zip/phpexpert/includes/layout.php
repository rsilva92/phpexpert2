<?php
// includes/layout.php — cabeçalho e rodapé compartilhados
if (!defined('APP_NAME')) { require_once __DIR__ . '/config.php'; }

function page_start(string $title = '', bool $requireAuth = true): void {
    if ($requireAuth) Auth::require();
    $fullTitle = $title ? "$title — " . APP_NAME : APP_NAME;
    $user = Auth::user();
    ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($fullTitle) ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@300;400;500;600;700&family=Geist:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/assets/css/app.css">
</head>
<body>

<div class="topbar">
  <div class="tb-logo">
    <div class="tb-mark">&lt;?</div>
    <span>PHP<span class="tb-accent">Expert</span></span>
  </div>
  <div class="tb-sep"></div>
  <nav class="tb-nav">
    <a href="/" class="tb-link <?= basename($_SERVER['PHP_SELF']) === 'index.php' ? 'active' : '' ?>">Trilha</a>
    <a href="/history.php" class="tb-link <?= basename($_SERVER['PHP_SELF']) === 'history.php' ? 'active' : '' ?>">Histórico</a>
    <a href="/export.php" class="tb-link <?= basename($_SERVER['PHP_SELF']) === 'export.php' ? 'active' : '' ?>">Exportar</a>
  </nav>
  <div class="tb-spacer"></div>
  <?php if ($user): ?>
  <div class="tb-user">
    <span class="tb-username"><?= htmlspecialchars($user['username']) ?></span>
    <a href="/logout.php" class="tb-btn-ghost">Sair</a>
  </div>
  <?php endif; ?>
</div>

<div class="app-wrap">
<?php
}

function page_end(): void {
    ?>
</div><!-- /app-wrap -->
<script src="/assets/js/app.js"></script>
</body>
</html>
<?php
}
