#!/bin/bash
# ============================================================
#  PHP Expert Platform — Instalador Automático
#  Compatível com Ubuntu 20.04 / 22.04 / 24.04 (Apache2 + MySQL/MariaDB)
# ============================================================
set -e

RED='\033[0;31m'; GRN='\033[0;32m'; YLW='\033[1;33m'
CYN='\033[0;36m'; BLD='\033[1m'; RST='\033[0m'

banner() {
  echo -e "${CYN}"
  echo "  ██████╗ ██╗  ██╗██████╗     ███████╗██╗  ██╗██████╗ ███████╗██████╗ ████████╗"
  echo "  ██╔══██╗██║  ██║██╔══██╗    ██╔════╝╚██╗██╔╝██╔══██╗██╔════╝██╔══██╗╚══██╔══╝"
  echo "  ██████╔╝███████║██████╔╝    █████╗   ╚███╔╝ ██████╔╝█████╗  ██████╔╝   ██║   "
  echo "  ██╔═══╝ ██╔══██║██╔═══╝     ██╔══╝   ██╔██╗ ██╔═══╝ ██╔══╝  ██╔══██╗   ██║   "
  echo "  ██║     ██║  ██║██║         ███████╗██╔╝ ██╗██║     ███████╗██║  ██║   ██║   "
  echo "  ╚═╝     ╚═╝  ╚═╝╚═╝         ╚══════╝╚═╝  ╚═╝╚═╝     ╚══════╝╚═╝  ╚═╝   ╚═╝   "
  echo -e "${RST}"
  echo -e "  ${BLD}Plataforma de Estudos PHP${RST} — baseada no livro de Pablo Dall'Oglio"
  echo "  ──────────────────────────────────────────────────────────────────"
  echo ""
}

log()  { echo -e "  ${GRN}✓${RST} $1"; }
warn() { echo -e "  ${YLW}!${RST} $1"; }
err()  { echo -e "  ${RED}✗${RST} $1"; exit 1; }
step() { echo -e "\n  ${CYN}▶${RST} ${BLD}$1${RST}"; }

# ── Verificar root ───────────────────────────────────────────
if [ "$EUID" -ne 0 ]; then
  err "Execute como root: sudo bash install.sh"
fi

banner

# ── Configurações ────────────────────────────────────────────
SITE_DIR="/var/www/phpexpert"
VHOST_DOMAIN="phpexpert.local"
DB_NAME="phpexpert"
DB_USER="phpexpert"

echo -e "  ${BLD}Configuração da instalação:${RST}"
echo ""
read -p "  Domínio/IP do site [$VHOST_DOMAIN]: " INPUT_DOMAIN
VHOST_DOMAIN="${INPUT_DOMAIN:-$VHOST_DOMAIN}"

read -s -p "  Senha para o usuário MySQL '$DB_USER': " DB_PASS
echo ""
if [ -z "$DB_PASS" ]; then
  DB_PASS="phpexpert$(date +%s | sha256sum | head -c 8)"
  warn "Senha gerada automaticamente: $DB_PASS (anote isso!)"
fi

read -p "  Senha root MySQL [deixe vazio se já autenticado]: " DB_ROOT_PASS
echo ""

step "Atualizando pacotes"
apt-get update -qq
log "apt update OK"

step "Instalando dependências: Apache2, PHP, MySQL, extensões"
DEBIAN_FRONTEND=noninteractive apt-get install -y -qq \
  apache2 \
  php8.1 php8.1-mysql php8.1-mbstring php8.1-xml php8.1-curl php8.1-zip php8.1-gd \
  mysql-server \
  libapache2-mod-php8.1 \
  unzip curl 2>/dev/null || \
DEBIAN_FRONTEND=noninteractive apt-get install -y -qq \
  apache2 \
  php php-mysql php-mbstring php-xml php-curl php-zip php-gd \
  mysql-server \
  libapache2-mod-php \
  unzip curl
log "Pacotes instalados"

step "Ativando módulos Apache"
a2enmod rewrite headers expires deflate
log "Módulos ativados"

step "Criando banco de dados e usuário MySQL"
if [ -n "$DB_ROOT_PASS" ]; then
  MYSQL_CMD="mysql -u root -p$DB_ROOT_PASS"
else
  MYSQL_CMD="mysql -u root"
fi

$MYSQL_CMD <<SQLEOF
CREATE DATABASE IF NOT EXISTS \`$DB_NAME\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS '$DB_USER'@'localhost' IDENTIFIED BY '$DB_PASS';
GRANT ALL PRIVILEGES ON \`$DB_NAME\`.* TO '$DB_USER'@'localhost';
FLUSH PRIVILEGES;

USE \`$DB_NAME\`;

CREATE TABLE IF NOT EXISTS users (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  username    VARCHAR(80)  NOT NULL UNIQUE,
  password    VARCHAR(255) NOT NULL,
  email       VARCHAR(150),
  created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS progress (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  user_id     INT NOT NULL,
  chapter_id  TINYINT NOT NULL,
  section_idx SMALLINT NOT NULL,
  done        TINYINT(1) DEFAULT 0,
  updated_at  DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY  uq_prog (user_id, chapter_id, section_idx),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS notes (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  user_id     INT NOT NULL,
  chapter_id  TINYINT NOT NULL,
  section_idx SMALLINT NOT NULL,
  note_text   TEXT,
  updated_at  DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY  uq_note (user_id, chapter_id, section_idx),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS history (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  user_id     INT NOT NULL,
  chapter_id  TINYINT NOT NULL,
  section_idx SMALLINT NOT NULL,
  sec_title   VARCHAR(300),
  viewed_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS exports (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  user_id     INT NOT NULL,
  export_type ENUM('txt','html') NOT NULL,
  filename    VARCHAR(200),
  created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

INSERT IGNORE INTO users (username, password) VALUES ('admin', '\$2y\$12\$demo_hash_replace_on_first_login');
SQLEOF
log "Banco de dados '$DB_NAME' criado com todas as tabelas"

step "Copiando arquivos do projeto"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
mkdir -p "$SITE_DIR"
cp -r "$SCRIPT_DIR/." "$SITE_DIR/"
mkdir -p "$SITE_DIR/exports"
log "Arquivos copiados para $SITE_DIR"

step "Criando arquivo de configuração"
cat > "$SITE_DIR/includes/config.php" <<PHPEOF
<?php
define('DB_HOST', 'localhost');
define('DB_NAME', '$DB_NAME');
define('DB_USER', '$DB_USER');
define('DB_PASS', '$DB_PASS');
define('DB_CHARSET', 'utf8mb4');
define('APP_NAME', 'PHP Expert');
define('APP_VERSION', '1.0.0');
define('APP_URL', 'http://$VHOST_DOMAIN');
define('EXPORT_DIR', __DIR__ . '/../exports/');
define('SESSION_LIFETIME', 86400 * 30);
PHPEOF
log "Config criada"

step "Configurando permissões"
chown -R www-data:www-data "$SITE_DIR"
chmod -R 755 "$SITE_DIR"
chmod -R 775 "$SITE_DIR/exports"
log "Permissões configuradas"

step "Criando VirtualHost Apache"
cat > "/etc/apache2/sites-available/phpexpert.conf" <<APACHEEOF
<VirtualHost *:80>
    ServerName $VHOST_DOMAIN
    DocumentRoot $SITE_DIR/public
    DirectoryIndex index.php

    <Directory $SITE_DIR/public>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>

    # Proteger includes e data
    <Directory $SITE_DIR/includes>
        Require all denied
    </Directory>
    <Directory $SITE_DIR/data>
        Require all denied
    </Directory>

    # Headers de segurança
    Header always set X-Content-Type-Options nosniff
    Header always set X-Frame-Options SAMEORIGIN
    Header always set X-XSS-Protection "1; mode=block"

    # Compressão e cache
    <IfModule mod_deflate.c>
        AddOutputFilterByType DEFLATE text/html text/css application/javascript text/plain
    </IfModule>

    ErrorLog \${APACHE_LOG_DIR}/phpexpert_error.log
    CustomLog \${APACHE_LOG_DIR}/phpexpert_access.log combined
</VirtualHost>
APACHEEOF

a2ensite phpexpert.conf
systemctl reload apache2
log "VirtualHost configurado: http://$VHOST_DOMAIN"

# Adicionar ao /etc/hosts se for .local
if [[ "$VHOST_DOMAIN" == *".local"* ]] || [[ "$VHOST_DOMAIN" =~ ^[0-9] ]]; then
  if ! grep -q "$VHOST_DOMAIN" /etc/hosts; then
    echo "127.0.0.1  $VHOST_DOMAIN" >> /etc/hosts
    log "/etc/hosts atualizado"
  fi
fi

step "Instalação concluída!"
echo ""
echo -e "  ┌─────────────────────────────────────────────────┐"
echo -e "  │  ${GRN}${BLD}Acesse:${RST}  http://$VHOST_DOMAIN"
echo -e "  │  ${GRN}${BLD}DB:${RST}      $DB_NAME @ localhost"
echo -e "  │  ${GRN}${BLD}Usuário:${RST} $DB_USER"
echo -e "  │  ${GRN}${BLD}Senha:${RST}   $DB_PASS"
echo -e "  │  ${YLW}Crie sua conta no primeiro acesso!${RST}"
echo -e "  └─────────────────────────────────────────────────┘"
echo ""
