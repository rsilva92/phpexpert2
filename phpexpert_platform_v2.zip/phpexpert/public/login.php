<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';
Auth::start();
if (Auth::id()) { header('Location: /'); exit; }

$mode  = $_GET['mode'] ?? 'login';
$error = '';
$ok    = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $email    = trim($_POST['email'] ?? '');

    if ($mode === 'login') {
        if (Auth::login($username, $password)) {
            header('Location: /');
            exit;
        }
        $error = 'Usuário ou senha incorretos.';
    } else {
        if (strlen($username) < 3) {
            $error = 'Username deve ter pelo menos 3 caracteres.';
        } elseif (strlen($password) < 6) {
            $error = 'Senha deve ter pelo menos 6 caracteres.';
        } elseif (Auth::register($username, $password, $email)) {
            Auth::login($username, $password);
            header('Location: /');
            exit;
        } else {
            $error = 'Username já em uso. Escolha outro.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $mode === 'login' ? 'Entrar' : 'Criar Conta' ?> — PHP Expert</title>
<link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600&family=Geist:wght@400;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/assets/css/app.css">
</head>
<body>
<div class="auth-wrap">
  <div class="auth-card">
    <div class="auth-logo">
      <div class="auth-logo-mark">&lt;?php</div>
      <div class="auth-logo-text">PHP<span>Expert</span></div>
    </div>

    <h1 class="auth-title"><?= $mode === 'login' ? 'Entrar na plataforma' : 'Criar sua conta' ?></h1>
    <p class="auth-sub">
      <?= $mode === 'login'
        ? 'Bem-vindo de volta! Continue sua trilha de estudos.'
        : 'Crie sua conta para salvar progresso, notas e histórico.' ?>
    </p>

    <?php if ($error): ?>
    <div class="flash flash-error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST">
      <div class="form-group">
        <label class="form-label">Username</label>
        <input class="form-input" type="text" name="username"
               value="<?= htmlspecialchars($_POST['username'] ?? '') ?>"
               placeholder="seu_usuario" required autofocus>
      </div>

      <?php if ($mode === 'register'): ?>
      <div class="form-group">
        <label class="form-label">E-mail <span class="text-muted">(opcional)</span></label>
        <input class="form-input" type="email" name="email"
               value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
               placeholder="voce@email.com">
      </div>
      <?php endif; ?>

      <div class="form-group">
        <label class="form-label">Senha</label>
        <input class="form-input" type="password" name="password"
               placeholder="••••••••" required>
      </div>

      <button class="btn btn-primary" style="width:100%;justify-content:center;padding:10px;font-size:.88rem;margin-top:4px" type="submit">
        <?= $mode === 'login' ? '→ Entrar' : '→ Criar Conta' ?>
      </button>
    </form>

    <p style="margin-top:18px;font-size:.78rem;color:var(--t3);text-align:center">
      <?php if ($mode === 'login'): ?>
        Não tem conta? <a href="/login.php?mode=register">Criar conta</a>
      <?php else: ?>
        Já tem conta? <a href="/login.php">Entrar</a>
      <?php endif; ?>
    </p>
  </div>
</div>
</body>
</html>
